# 【主义主义预习课】何为暴力？力量之表象；怎么得出这一结论？对原因和实体的关系进行探索（从$\-2\-1\-3到$\-2\-1\-4）: verification reference

AI draft; human review required.

Revision: `adc42cf2c595d1020bfa5d30f08588e8ff6d901363112e6eec426da854a3e07c`

Input: `d39fd0226f39458edcbc45c12877968085ff5f445a71fa5f667d6a9d704037f4`

Model: `deepseek\-v4\.1\-flash`; template: `ai-draft-v2`

Base transcript: `600`; digest: `72900956eec8fdb8721ed34ddbc11d3036eb51341d14fe4b9f7c76a3e7b3b3c1`

Reference transcript: none

Prompt digest: `4d5cea1b14275993b3999ccb74508cbad793d83a5486ed6f0227dbea1c384d40`; source rule: `multilingual-prose-v2`

Configuration: `\{"base\_url":"https://opencode\.ai/inference/go/v1","budget\_policy":"token\-budget\-v2","chunk\_preset":"large\-v1","context\_segments":2,"context\_tokens":1000000,"max\_chunk\_chars":6000,"max\_chunk\_regenerations":2,"max\_chunk\_segments":80,"max\_input\_tokens":240000,"max\_output\_tokens":65536,"model":"deepseek\-v4\.1\-flash","reasoning\_effort":"low","request\_policy":"deepseek\-v2","rule\_version":"readable\-prose\-v2","safety\_tokens":16384,"temperature":null,"thinking\_mode":"enabled","timeout\_seconds":1200,"top\_p":0\.95\}`

Source: [bilibili / BV1cq4y1t7TN](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1)

Source published at: 2022-02-14T16:50:12Z

## Paragraph 1: 160–19280 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=0)

Segments: `t600:s0`, `t600:s1`, `t600:s2`, `t600:s3`

Original: 我们今天讲主一主的预习课，这个预习课就是下面的二杠一杠四的预习课，我们需要把文本先先把课文读一遍吧，啊，就是行动啊，作用和反作用，action andreaction啊，或者行动和反行动啊，可以翻译成行动和反动了。

Edited: 我们今天讲主一主的预习课，这个预习课就是下面的二杠一杠四的预习课，我们需要先把文本、先把课文读一遍。就是行动啊、作用和反作用，action and reaction，或者行动和反行动，可以翻译成行动和反动了。

- “主一主”疑为课程或文本标题，无法确定; 主一主（原文如此）; t600:s0
- “反动了”疑为“反行动”; 反行动; t600:s3

## Paragraph 2: 20800–50880 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=20)

Segments: `t600:s4`, `t600:s5`, `t600:s6`, `t600:s7`

Original: 然后呃运运行到这边呢，这个cosolidity已经暴露出来，它是一个预设性的啊，presupposing预设者的活动性啊，它这种活动性，它这个活动性属于这个主动性，这个主动性就是principles，principle something，principle somethingthat就是把这个东西早就存在了，它原因这个东西就是就是前面讲过了，这个cosolidity就是它设了一个东西，并且把这个东西说这个东西早就在这边

Edited: 然后运行到这边呢，这个 cosolidity 已经暴露出来，它是一个预设性的、presupposing 预设者的活动性。它这种活动性属于这个主动性，这个主动性就是 principles、principle something、principle something that，就是把这个东西早就存在了；原因这个东西就是——前面讲过了——这个 cosolidity 就是它设了一个东西，并且把这个东西说成早就在这边了。

- “cosolidity”疑为“causality”; causality; t600:s4
- “principle something”为原文重复表述，具体所指不确定; principle something（原文如此）; t600:s5

## Paragraph 3: 52800–76800 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=52)

Segments: `t600:s8`, `t600:s9`, `t600:s10`

Original: 了，啊，它就这种活动性啊，它是一种，但这种活动性有好几个啊，这个presupposing的东西其实前面有好几个啊，不仅仅是cosolidity，它就是它cosolidity就是把effect设定下来，这个effect会说，哎，早就有这个cause让这个effect变成一个effect出来，

Edited: 它这种活动性是一种……但这种活动性有好几个，这个 presupposing 的东西其实前面有好几个，不仅仅是 cosolidity。cosolidity 就是把 effect 设定下来，这个 effect 会说：哎，早就有这个 cause，让这个 effect 变成一个 effect 出来。

## Paragraph 4: 78000–98720 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=78)

Segments: `t600:s11`, `t600:s12`, `t600:s13`

Original: 然后在这个情况下，这cause isconditioned啊，这个原因啊，它就是有条件的conditioned，it is negative reference toitself，它是一个否定性的指称指向自己啊，它作为一个被预设的东西啊，它就变成有条件的东西了，它否定性的指向自己啊，是

Edited: 然后在这个情况下，这 cause is conditioned，这个原因啊，它就是有条件的，conditioned，it is negative reference to itself，它是一个否定性的指称、指向自己。它作为一个被预设的东西，就变成有条件的东西了；它否定性地指向自己。

## Paragraph 5: 98880–142400 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=98)

Segments: `t600:s14`, `t600:s15`, `t600:s16`, `t600:s17`, `t600:s18`

Original: 通过什么指向自己啊？通过effect，通过效果，它否定性的指向指向自己，说这个cause早就在那边了，effect说早就有个cause有一个原因在那边了，啊，就叫做把自己设立成啊，就是指向自己，否定性的指指向自己，然后是一个，然后我是effect，我不是那个cause，所以叫否定性的指向自身，把自己指向，而且是把自己变成一个本就在那边，我是effect，我这个effect之前就有个cause，我不是那个cause，就是否定性的指向他自己，实际上就是他自己了，然后说那个cause早就在那边，也就是说把那个cause

Edited: 通过什么指向自己？通过 effect，通过效果，它否定性地指向自己，说这个 cause 早就在那边了；effect 说早就有个 cause、有一个原因在那边了。这就叫做把自己设立成……就是指向自己、否定性地指向自己。然后我是 effect，我不是那个 cause，所以叫否定性地指向自身，把自己指向，而且是把自己变成一个本就在那边：我是 effect，我这个 effect 之前就有个 cause，我不是那个 cause。就是否定性地指向他自己，实际上就是他自己了。然后说那个 cause 早就在那边，也就是说把那个 cause 当成一个 presupposed、早就预设好的一个东西，否定性地指向了一个东西。

## Paragraph 6: 142400–192213 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=142)

Segments: `t600:s19`, `t600:s20`, `t600:s21`, `t600:s22`, `t600:s23`, `t600:s24`, `t600:s25`, `t600:s26`, `t600:s27`, `t600:s28`, `t600:s29`

Original: 当成一个presupposed早就预设好的一个东西，否定性的指向了一个东西，那它所以它是一个啊预设性的活动性，它把自己当成一个早就存在的东西设定在设定在自己后面或者自己前面啊，说我早就在那边了啊，然后as然后它就是说作为一个啊作为一个外在的一个他者externalother啊外部的一个他者，which is which inself啊，but only in itself is cosolidityitself，这个东西呢它自在的，并且仅仅是自在，但是它仅仅是在才是。原因性本身才是causality，起因性本身causality本身就那个背后的那个causality，背后那个causality，就他把自己啊设立成是一个external

Edited: 所以它是一个预设性的活动性，它把自己当成一个早就存在的东西，设定在自己后面或者自己前面，说“我早就在那边了”。然后它就是说，作为一个外在的一个他者，external other，外部的一个他者，which is in self，but only in itself is cosolidity itself。这个东西呢，它自在的，并且仅仅是自在；但是它仅仅是在……原因性本身才是 causality，起因性本身、causality 本身，就是背后那个 causality，背后那个 causality。就他把自己设立成是一个 external other。

- “cosolidity itself”疑为“causality itself”; causality itself; t600:s23

## Paragraph 7: 192213–236933 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=192)

Segments: `t600:s30`, `t600:s31`, `t600:s32`, `t600:s33`, `t600:s34`, `t600:s35`, `t600:s36`

Original: other，他只有在他自身当中，就封闭的来看这个设定过程本身，封闭的来看这么一个这么一个活动过程本身啊，作为一个external other，这个external other就是他只有在他自己当中封闭的看这么一个，就是我背后早就有个大哥是是cause，是cause，或者说我背后早就有个大哥，这个东西甚至都甚至只有在他in这个背后就是cause了，背后是cause，然后这个东西这个cause是一个被presupposed的一个东西，是个意在是一个蛇皮东西presupposed

Edited: 他只有在他自身当中，就封闭地来看这个设定过程本身、封闭地来看这么一个活动过程本身，作为一个 external other。这个 external other 就是他只有在他自己当中封闭地看这么一个：就是我背后早就有个大哥，是 cause；或者说我背后早就有个大哥，这个东西甚至只有在他 in……这个背后就是 cause 了，背后是 cause。然后这个东西、这个 cause 是一个被 presupposed 的一个东西，是一个被 presupposed 的一个东西。

- “蛇皮东西”等口语或识别噪声，按“presupposed 的东西”处理; presupposed 的东西; t600:s36

## Paragraph 8: 236933–266933 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=236)

Segments: `t600:s37`, `t600:s38`, `t600:s39`, `t600:s40`, `t600:s41`, `t600:s42`

Original: 的一个东西，但是就其自己而言啊，孤立的就其内在而言，他自己看他自己，他会觉得他是causality，他是causality，施加在一个东西上面，施加在一个东西上面，就是only in itself它才是causality，啊，但是我们很多庸常的人就以为那个cause就是causality，不是，那个cause实际上是一个presupposed negative reference toitself，啊，to to effect the

Edited: 但是就其自己而言，孤立地就其内在而言，他自己看他自己，他会觉得他是 causality，他是 causality，施加在一个东西上面，施加在一个东西上面。就是 only in itself，它才是 causality。啊，但是我们很多庸常的人就以为那个 cause 就是 causality；不是，那个 cause 实际上是一个 presupposed、negative reference to itself，啊，to effect，the……

## Paragraph 9: 268133–280773 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=268)

Segments: `t600:s43`, `t600:s44`, `t600:s45`, `t600:s46`

Original: 这个背后的那个cause是一个presupposed，啊，然后是一个negative reference toeffect，是effect是一个效果对于他自己的否定性指称，

Edited: 这个背后的那个 cause 是一个 presupposed，然后是一个 negative reference to effect，是 effect，是一个效果对于他自己的否定性指称。

## Paragraph 10: 283573–313013 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=283)

Segments: `t600:s47`, `t600:s48`, `t600:s49`, `t600:s50`, `t600:s51`

Original: 啊，然后这个东西就是只就是仅在他自己看来，他好像是一个好像设定性的力量，很屌的一个力量，就是这个背后的那个cause，仅在它in itself里面啊，作为一个外在东西，它仅在它in itself里面，它才是causalityitself，它才是个causality，或就这个理解你就类似于就是说呃举个例子，就比如说呃费希特的鲜艳自我

Edited: 然后这个东西就是仅在它自己看来，他好像是一个设定性的力量，很屌的一个力量，就是这个背后的那个 cause；仅在它 in itself 里面，作为一个外在东西，它仅在它 in itself 里面，它才是 causality itself，它才是个 causality。或者就这个理解，你就类似于说，举个例子，就比如说费希特的鲜艳自我、transcendental……

- “鲜艳自我”疑为“先验自我”; 先验自我; t600:s51

## Paragraph 11: 313653–351333 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=313)

Segments: `t600:s52`, `t600:s53`, `t600:s54`, `t600:s55`, `t600:s56`, `t600:s57`, `t600:s58`

Original: transcendental，就是就是就是ish，就是那个ish加引号的ish，就是我自我，他自我学嘛，知识学，那个东西也是的，那个东西仅就它在它自身当中，它才是纯粹知识，它才是pureknowledge，这里类似的理解就是说这个cause，我这个effect背后有个cause，这个cause仅就他自己封闭的看他自己，封闭的就就他内在他就是自顾自的，他才是他才是啊，他才是causality，实际上他他就是说他以他才以为他在对这个effect

Edited: 就是那个 ish，就是那个 ish 加引号的 ish，就是我自我，他自我学嘛、知识学，那个东西也是的：那个东西仅就它在它自身当中，它才是纯粹知识，它才是 pure knowledge。这里类似的理解就是说：这个 cause——我这个 effect 背后有个 cause——这个 cause 仅就他自己封闭地看他自己，封闭地、就他内在地，他就是自顾自的，他才是 causality。实际上他就是说，他以为他在对这个 effect 在施加什么力量。

- “ish”所指不确定，似为引号中的术语; ish（原文如此）; t600:s52

## Paragraph 12: 351333–392225 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=351)

Segments: `t600:s59`, `t600:s60`, `t600:s61`, `t600:s62`, `t600:s63`, `t600:s64`, `t600:s65`

Original: 在施加什么力量啊，this other is as we have seen the substantialidentity，呃。呃，into which formal causality passes over。那么这么一个他者，这个externalother啊，就是说这个时候原因因果性被固定到说effect背后有个cause，就是之前上面一环有cause，就cause会被看成是一个实体啊，这么一个外在他者，如我们所见，它会被看成是一个实体性的同一性啊，它是一种实体性同一性啊形式的形式的啊这个因果性呢，形式的起因性呢，就是pass over intoit，转入了，对吧？

Edited: this other is as we have seen the substantial identity，呃，into which formal causality passes over。那么这么一个他者，这个 external other 啊，就是说这个时候原因、因果性被固定到说 effect 背后有个 cause，就是之前上面一环有 cause，就 cause 会被看成是一个实体。这么一个外在他者，如我们所见，它会被看成是一个实体性的同一性；它是一种实体性同一性。形式的……形式的啊，这个因果性呢、形式的起因性呢，就是 pass over into it，转入了，对吧？过渡到了这种实体性的同一性当中，substantial identity，which……

## Paragraph 13: 392385–416705 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=392)

Segments: `t600:s66`, `t600:s67`, `t600:s68`

Original: 过渡到了这种啊实体性的同一性当中，substantial identity，whichnow这个时候就会，这个时候就我们就会说cause它是一个实体，它是一个东西一个一个原因啊cause就形式causality就pass over into the substantialidentity啊实体性同一性里面去了，

Edited: 这个时候就会，这个时候我们就会说 cause 它是一个实体，它是一个东西、一个原因；cause 就形式 causality 就 pass over into the substantial identity，实体性同一性里面去了。

## Paragraph 14: 417745–473105 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=417)

Segments: `t600:s69`, `t600:s70`, `t600:s71`, `t600:s72`, `t600:s73`, `t600:s74`

Original: 进去了之后，我们就可以说有一个cause，然后它导致了一个effect，导致了一个效果，which now has determined itself as against this causality as its negative。那么现在呢，这个东西，这个他者，实存性的他者呢，它现在呢，把自己已经把自己规定成是和这个因果性形式因果性对立的一个东西，作为它的否定项，作为它的negative，作为它的否定侧和它对立起来，那么这个cause就是好像是要从这个这个cause当中发起出一个causality出来，然后过渡到这个effect上面啊，那么这个形式因果性呢，它就是和这个cause啊substantialidentity这个cause对立起来，cause andcausality就对立起来了，它把自己对立起来了，or it is the same as the substance of the causal

Edited: 进去了之后，我们就可以说有一个 cause，然后它导致了一个 effect、导致了一个效果，which now has determined itself as against this causality as its negative。那么现在呢，这个东西、这个他者、实存性的他者呢，它现在已经把自己规定成是和这个因果性、形式因果性对立的一个东西，作为它的否定项、作为它的 negative、作为它的否定侧和它对立起来。那么这个 cause 就好像是要从这个 cause 当中发起出一个 causality 出来，然后过渡到这个 effect 上面。那么这个形式因果性呢，它就是和这个 cause、substantial identity 这个 cause 对立起来，cause and causality 就对立起来了；它把自己对立起来了，or it is the same as the substance of the causal relation……

## Paragraph 15: 473105–514225 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=473)

Segments: `t600:s75`, `t600:s76`, `t600:s77`, `t600:s78`, `t600:s79`

Original: relation，或者说它就是同样的就是那个呃因果关系当中的那个实体啊，因果关系当中的实体，但是它是这样一个实体，but which is confronted by the power of accidentality as itself substantial activity。啊，它但它是这样一个实体，它是面对着这个偶性性的那个力量的，the power ofaccidentality，偶性性的力量本身才是才是真的力量啊，实实体性的活动性，偶性性的力量本身才是力量，偶性性的power ofaccidentality其实就是power ofcausality，偶性性的力量就是实体性的力量，呃就就

Edited: 或者说它就是同样的，就是那个因果关系当中的那个实体，因果关系当中的实体，但是它是这样一个实体，but which is confronted by the power of accidentality as itself substantial activity。啊，它是这样一个实体，它是面对着这个偶性性的那个力量的；the power of accidentality，偶性性的力量本身才是真的力量，实体性的活动性，偶性性的力量本身才是力量，偶性性的 power of accidentality 其实就是 power of causality，偶性性的力量就是实体性的力量。

- “偶性性”疑为“偶然性”或“偶性”，术语译法不确定; 偶然性/偶性; t600:s76

## Paragraph 16: 515505–546192 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=515)

Segments: `t600:s80`, `t600:s81`, `t600:s82`, `t600:s83`

Original: 就是实体的活动性，也就是因果性，就是起因性的力量，就是causality作为一个power，它是属于accidentality的，因为accidentality是你妈的那个引发这个效果的嘛，引发这个回指这个效果的啊，所以这个时候这个实体，但这个实体就和它对立起来了，和这个power of accidentalaccidentality就和它对立起来了啊，而这个accidentality的力量，则它本身则是这个实体的活动性。

Edited: 这就是实体的活动性，也就是因果性，即起因性的力量；causality 作为一种 power，属于 accidentality。因为 accidentality 引发这个效果，引发这个回指的效果，所以这个时候这个实体就和它对立起来了，和这个 power of accidentality 对立起来；而 accidentality 的力量本身则是这个实体的活动性。

- accidentality 可能为转写或术语形式不确定；保留原词; accidentality; t600:s80, t600:s82, t600:s83

## Paragraph 17: 546192–580752 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=546)

Segments: `t600:s84`, `t600:s85`, `t600:s86`, `t600:s87`, `t600:s88`

Original: 所以这个时候，这个cause变成一个实体，这个实体只是纯粹的和和这个起因性对立起来，和这个causality对立，和这个accidentality对对立。为什么要和它对立？为什么要和它对立？因为它要自，它要把自己预设下来，我早就在这边。所以它要和这个这个活的东西呢，这个活的东西就是会回来看穿这个轨迹，看穿它这个自己把自己设定下来的这个预设出来的这么一个轨迹，所以它要和这个轨迹对立起来。

Edited: 所以这个时候，这个 cause 变成一个实体，这个实体只是纯粹地和这个起因性对立起来，和 causality 对立，和 accidentality 对立。为什么要和它对立？因为它要把自己预设下来：我早就在这边。所以它要和这个活的东西对立起来；这个活的东西会回来看穿这个轨迹，看穿它自己把自己设定下来、预设出来的这么一个轨迹，所以它要和这个轨迹对立起来。

- cause、causality 等英文术语在转写中夹杂，保留原样; cause; t600:s84, t600:s85

## Paragraph 18: 581072–617872 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=581)

Segments: `t600:s89`, `t600:s90`, `t600:s91`, `t600:s92`, `t600:s93`

Original: 这个accidentality和这个causality其实都是一种轨迹，其实都是一种轨迹和或者说这个形式形式formal形式因果性和这个accidentality他妈是一个东西，它都是轨迹。这个轨迹就是在前面的东西，既然可以回指一个背后的一个大哥，你爸的凭什么这样？不能这样，不能这样，就是我大哥本就在这边，所以大哥本就在这边，这个大哥本就在那边，这个本就在本就自我同意，实体性的自我同意就会和这个轨迹性的力量和它对立起来啊，对立起来。

Edited: 这个 accidentality 和这个 causality 其实都是一种轨迹；或者说，形式因果性，formal 形式因果性，和这个 accidentality 其实是同一个东西，它们都是轨迹。这个轨迹就是在前面东西的轨迹：既然它可以回指一个背后的大哥，那凭什么这样？不能这样。就是我大哥本就在这边，大哥本就在这边，这个大哥本就在那边；这个“本就在”就是自我同一，实体性的自我同一就会和这个轨迹性的力量对立起来。

- 轨迹性力量与实体性自我同一的关系转写不完整，按原意保留; 自我同一; t600:s92, t600:s93

## Paragraph 19: 618352–645152 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=618)

Segments: `t600:s94`, `t600:s95`, `t600:s96`, `t600:s97`

Original: 那么这个东西它自己它自己则是实体性的活动性啊，这个东西才是真的实体性的活动性，这个东西是屌的，是厉害的啊。但是这个时候大哥变得僵硬了，大哥把自己伪装成就是cause啊，把自己把自己伪装成那个causalrelation的那个实体，那么这个实体就是一个被动的实体，就是个passive substance，passivesubstance就是被动的实体。然后passive is that which is

Edited: 那么这个东西自己则是实体性的活动性；这个东西才是真正的实体性的活动性，是很厉害的。但是这个时候大哥变得僵硬了，大哥把自己伪装成 cause，把自己伪装成那个 causal relation 的实体；那么这个实体就是一个被动的实体，就是 passive substance，passive substance 就是被动的实体。

## Paragraph 20: 645152–711312 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=645)

Segments: `t600:s98`, `t600:s99`, `t600:s100`, `t600:s101`, `t600:s102`, `t600:s103`, `t600:s104`, `t600:s105`, `t600:s106`, `t600:s107`, `t600:s108`, `t600:s109`, `t600:s110`

Original: immediate，它被动的啊，它就是啊，什么是被动呢？就是那个直接的东西，that which is immediate immediate ispassive，它是直接的，or which exists in self but is not also foritself，它就是那个自在实存的，但又不是啊为它自己实存的一个东西，它是自顾自的实存的，就是愣头青的觉得自己是是在呃决定一切、主宰一切的，它是出来的，愣头青的觉得自己是出来的。但是呢，but is not also foritself，但是它这个出来并没有任何的没有任何的目的啊，或者说没有任何的意义，没有任何的就看到它是在计划之中的，它没有任何的计划性啊，没有任何的计划性。foritself呢就就是没有，就是它这个自我确证是一个盲目的自我确证，是一个就是一个直接性不加中介的一个自我确证啊，没有把自己展露出来的，but not for itself，not foritself，just initself啊，isnot，这个就是被动啊，被动的一个东西。

Edited: 然后 passive is that which is immediate；它是被动的。什么是被动呢？就是那个直接的东西：that which is immediate，immediate is passive。它是直接的，or which exists in self but is not also for itself；它就是那个自在实存的、但又不是为它自己实存的东西。它自顾自地实存，像愣头青一样觉得自己是在决定一切、主宰一切，它是出来的，愣头青一样觉得自己是出来的。但是，but is not also for itself，它这个出来并没有任何目的，或者说没有任何意义，看不到它是在计划之中的，它没有任何计划性。for itself 呢，就是没有；它的自我确证是一个盲目的自我确证，是一个直接性、不加中介的自我确证，没有把自己展露出来，but not for itself，not for itself，just in itself，is not；这个就是被动，被动的一个东西。

- just in itself、is not 等处句法破碎，按原词保留; just in itself; t600:s107, t600:s108, t600:s109

## Paragraph 21: 711312–780436 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=711)

Segments: `t600:s111`, `t600:s112`, `t600:s113`, `t600:s114`, `t600:s115`, `t600:s116`, `t600:s117`, `t600:s118`, `t600:s119`, `t600:s120`

Original: 这个时候这个时候原因cause就会被看成是一个实体，或者说就是会被看成这个因果关联因果关系当中的啊它的实体它的substance，然后啊。Pure being or essence in just this determinateness of abstract selfidentity，它只是纯粹的存在或者纯粹的本质啊啊在在这种规定性当中，在哪种规定性啊，在哪种确定状态啊，在哪种确定状态，明确状态啊，就是说抽象自身同一性啊，它只是一个抽离的自身同一，抽离的自我同一性的一个一个规定规定状态，它被什么东西规定？就是被一个抽离了的自我同一所规定，它只是abstract selfidentity，所以它是initself，所以它是initself啊，它是exist，它是实存的出来的，所以它这里purebeing就是说就用了allessence，就是啊它就说这它是existence，existence这个东西就非常有意思，它是个实存嘛，所以啊它是这里加个all，为什么黑格尔在这里加个all啊？

Edited: 这个时候，原因 cause 就会被看成是一个实体，或者说被看成因果关联、因果关系当中的实体，它的 substance。然后：Pure being or essence in just this determinateness of abstract self identity；它只是纯粹的存在或者纯粹的本质，在这种规定性当中——在哪种规定性、哪种确定状态、哪种明确状态呢？就是说抽象自身同一性。它只是一个抽离的自身同一、抽离的自我同一性的规定状态；它被什么东西规定？就是被一个抽离了的自我同一所规定。它只是 abstract self identity，所以它是 in itself；它是 exist，它是实存地出来的。所以这里 pure being 就是说，用了 all essence；它说这是 existence。existence 这个东西非常有意思，它是个实存，所以这里加个 all。为什么黑格尔在这里加个 all 啊？

- all essence 处转写不清，保留原词; all essence; t600:s118, t600:s119

## Paragraph 22: 780436–795156 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=780)

Segments: `t600:s121`, `t600:s122`, `t600:s123`

Original: 其实挺值得玩味的，因为它是个existence，但是它没有办法做到foritself，这个existence没法返回它自己，它只是in itself，not foritself，它无法返回它自己，所以它只是个孤零零的一个being。

Edited: 其实挺值得玩味的：因为它是个 existence，但是它没有办法做到 for itself；这个 existence 没法返回它自己，它只是 in itself，not for itself，它无法返回它自己，所以它只是个孤零零的一个 being。

## Paragraph 23: 795396–842756 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=795)

Segments: `t600:s124`, `t600:s125`, `t600:s126`, `t600:s127`, `t600:s128`, `t600:s129`, `t600:s130`

Original: 那另外一方面又可以说它是个essence，这个essence实际上是有贬义的啊，它只是个essence，它不是一个concreteexistence，所以它只是一个initself，蒙在里面的这个essence是一个相当于being的一个essence，它不是concreteexistence，你不要说前面说是说它是exist initself，所以它后面说它essence是在抬举它，不是的，没有抬举它啊，这里说这他他他还是一个就是不明所以的，就是就自顾自在那边的一个东西，我就是原因，我就是大哥，我就是大哥，就是往那一站啊，就是因果网络全全要铺设在我身上，从我这里发出，我来吧，它就是个被动性passivity，被动的一个东西。Confronting the passive substance is negatively self\-referent

Edited: 那另外一方面又可以说它是个 essence；这个 essence 实际上是有贬义的。它只是个 essence，它不是一个 concrete existence，所以它只是一个 in itself。蒙在里面的这个 essence 是一个相当于 being 的 essence，它不是 concrete existence。你不要说前面说它是 exist in itself，所以后面说它 essence 是在抬举它——不是的，没有抬举它。这里说它还是一个不明所以的、自顾自在那边的一个东西：我就是原因，我就是大哥，我就是大哥，就往那一站，因果网络全都要铺设在我身上，从我这里发出，我来吧；它就是个被动性 passivity，被动的一个东西。

- essence 是否带贬义为讲者判断，按原话保留; essence; t600:s124

## Paragraph 24: 842756–904516 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=842)

Segments: `t600:s131`, `t600:s132`, `t600:s133`, `t600:s134`, `t600:s135`, `t600:s136`, `t600:s137`

Original: substance，那面对这么一个被动的这个实体呢啊，和它相对立的是什么呢？是一个否定性的自我指涉的一个实体啊，是一个否定性的自我指涉，the negatively self\-referentsubstance有另外一个实体，就是活络的那个实体啊，它是面对的这个东西，活络这个实体是那个the efficientsubstance，是那个起效用的实体，那个有效的实体，起效用的实体啊，it is caused in as much as in determinate causality it has restored itself out of the effect through the negation ofitself啊，就是说在那个明确的因果性当中啊，在determinate啊就是规定规定的就是我们就可以翻译成确定的，在确定的因果性当中啊是原因啊是原因啊，只要是在确定的因果性当中是恰恰是原因，它保存了它自身从结果当中保存了它是restore restore itself out of theeffect啊。

Edited: 面对这么一个被动的实体，和它相对立的是什么呢？是一个否定性的自我指涉的实体，the negatively self\-referent substance。有另外一个实体，就是活络的那个实体；它是面对这个东西的，活络这个实体是 the efficient substance，是那个起效用的实体、有效的实体、起效用的实体。it is caused in as much as in determinate causality it has restored itself out of the effect through the negation of itself；就是说，在明确的因果性当中——在 determinate，也就是规定的、我们可以翻译成确定的——在确定的因果性当中，只要是在确定的因果性当中是原因，它保存了它自身，从结果当中保存了它，是 restore itself out of the effect。

- determinate causality 的译法不确定，暂作“确定的因果性”; determinate causality; t600:s135, t600:s136

## Paragraph 25: 905601–962321 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=905)

Segments: `t600:s138`, `t600:s139`, `t600:s140`, `t600:s141`, `t600:s142`, `t600:s143`, `t600:s144`, `t600:s145`, `t600:s146`, `t600:s147`, `t600:s148`

Original: 从这个效效果，从它效果当中把自己保存下来啊，保存下来，through the negation ofitself，通过什么？通过自我否否定，通过自我否定啊，就是说，它意思就是说，这个原因怎么把自己保存起来？我不是原因了，I am no longer cause，I am just something indifferent，I am the former cause ofyourself，不是我，不是我，不是原因了，这个cause就它能它能把自己从这个效果当中保存下来的唯一一个方式，就通过自我否定，I am no longer cause，I I I don't havecausality，这个cause就变成一个被动的一个实体了，就变成一个被动的一个实体了，然后它是一个reflected being，which in its otherness or as an immediate behaves essentially as a positingactivity，呃，and through its negation meditatesitself，呃，它就是一个

Edited: 从这个效果、从它效果当中把自己保存下来，通过什么？through the negation of itself，通过自我否定。就是说，这个原因怎么把自己保存起来？我不是原因了，I am no longer cause，I am just something indifferent，I am the former cause of yourself；不是我，不是原因了。这个 cause 能把自己从这个效果当中保存下来的唯一方式，就是通过自我否定：I am no longer cause，I don't have causality。这个 cause 就变成一个被动的实体了，就变成一个被动的实体了。然后它是一个 reflected being，which in its otherness or as an immediate behaves essentially as a positing activity，and through its negation meditates itself。

- meditates 可能是 mediates 的转写，保留原词; meditates; t600:s147

## Paragraph 26: 963921–981441 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=963)

Segments: `t600:s149`, `t600:s150`, `t600:s151`

Original: 被这个拉伸它添的啊，就是，Hegel's sentence does not otherwisepass啊，这是添的啊，这是，这是拉拉伸添上去了，

Edited: 这是被拉伸添上去的；Hegel's sentence does not otherwise pass，这是添的，这是拉伸添上去的。

- “拉伸”疑为专名或误转写，未改；与 Hegel's sentence does not otherwise pass 的关系不清; 拉伸; t600:s149, t600:s151

## Paragraph 27: 982641–1061841 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=982)

Segments: `t600:s152`, `t600:s153`, `t600:s154`, `t600:s155`, `t600:s156`, `t600:s157`, `t600:s158`, `t600:s159`, `t600:s160`, `t600:s161`, `t600:s162`, `t600:s163`

Original: 呃，which这么一个which in itsotherness啊，这么这么一个原因啊，这个原因cause就是它是一个是个实体，它是个东西，它是在那个因果关系当中的一个原因，不是原因性，不是causality，不是causality，它在它的他异性当中，otherness，哎，这个他异性也不就前面的externalother啊，以它的他异性或者说作为一个直接直接者啊，或者说不加中介的一个东西啊，作为一个initself的一个蛇皮东西，behavesessentially as a positingactivity，它本质性的一定会作为一个啊设定性的活动性a positingactivity起作用，and through its negation meditatesitself，然后通过它的否定来中介它自己，通过它的否定来中介它自己，通过它的否认来中介它自己，它因为它作为一个otherness啊otherness，它不可避免的它一定会essentially啊按其本质作为other的一个东西，作为一个reflectedbeing，啊这个是添下去的啊，添进去的，就是它告诉一个被反思的这个一个存在肯定会按照这种方式来来来运动，a reflected being，it's a reflected

Edited: which in its otherness：这么一个原因，这个原因（cause）就是一个实体，是一个东西，它是在那个因果关系当中的一个原因，不是原因性，不是 causality。它在它的他异性当中（otherness）——这个他异性也不就是前面的 external other——以它的他异性，或者说作为一个直接者，或者说不加中介的东西，作为一个 in itself 的蛇皮东西，behaves essentially as a positing activity。它本质性地一定会作为一个设定性的活动性、a positing activity 起作用，and through its negation mediates itself；然后通过它的否定来中介它自己，通过它的否认来中介它自己。因为它作为一个 otherness，它不可避免地一定会 essentially 按其本质作为 other 的东西，作为一个 reflected being——啊，这个是添下去的、添进去的：它就是告诉一个被反思的存在，肯定会按照这种方式来运动，a reflected being，it's a reflected being。

## Paragraph 28: 1061921–1147516 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1061)

Segments: `t600:s164`, `t600:s165`, `t600:s166`, `t600:s167`, `t600:s168`, `t600:s169`, `t600:s170`, `t600:s171`, `t600:s172`, `t600:s173`, `t600:s174`, `t600:s175`, `t600:s176`

Original: being是一个被反思的存在，就是这个东西是个很很很膈应的一个东西，你看一个being它只能是一个直接那个being，它竟然是个被反思的being，reflected being，how could being be reflected？那么它一定会做后面的事情啊，一个一个being如果它被因为这个being是什么immediacy？直接性，但是他既然他被反思了，就像这个时候这个原因啊也是啊，他被反思了，reflected是一个或者说我们说它是一个被反思出来的一个being，就这个cause，这个时候这个cause把自己拯救出来了嘛，把自己从这个炸生炸灭或不停的献祭的因果网络里面拯救出来了，不是因果网络，他就是说把自己变成这个因果网络里面的一个被动的一个实体啊，好像cosolidity加载在这么一个substance上面变成一个cause，这个cause再传递到下面一个effect上面去，然后这个effect我操，然后他自己又又变成一个有cosolidity的一个substance，然后再再搞到下面一个上面去，你懂吗？就这么个意思，所以在这种情况下，啊，这个cause我们说它是一个a reflectedbeing，reflectedbeing啊是一个被反思啊一个反思出来的被反思了的一个存在，这个存在就是它被炮制出来的，它是被被被短路出来的一个一个自在

Edited: being 是一个被反思的存在，这个东西很膈应。你看，一个 being 只能是一个直接的 being，它竟然是个被反思的 being，reflected being——how could being be reflected？那么它一定会做后面的事情。一个 being，如果它被……因为这个 being 是什么？immediacy？直接性。但是他既然被反思了，就像这个时候这个原因也被反思了，reflected；或者说我们说它是一个被反思出来的一个 being。就这个 cause，这个时候这个 cause 把自己拯救出来了，把自己从这个炸生炸灭或不停献祭的因果网络里面拯救出来了——不是因果网络，他就是说把自己变成这个因果网络里面的一个被动的实体，好像 cosolidity 加载在这么一个 substance 上面，变成一个 cause，这个 cause 再传递到下面一个 effect 上面去；然后这个 effect 又变成一个……然后他自己又变成一个有着 cosolidity 的一个 substance，然后再搞到下面一个上面去，你懂吗？就这么个意思。所以在这种情况下，这个 cause，我们说它是一个 a reflected being，reflected being，是一个被反思、一个反思出来的、被反思了的一个存在。这个存在就是它被炮制出来的，它是被短路出来的一个自在。

- 源转写为“炸生炸灭”，语义不确定，疑为“乍生乍灭”；正文保留原词。; 乍生乍灭; t600:s169
- 术语转写不确定，疑为 solidity 或 co\-solidity；正文保留原词。; solidity/co\-solidity; t600:s170, t600:s171, t600:s172

## Paragraph 29: 1147836–1288255 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1147)

Segments: `t600:s177`, `t600:s178`, `t600:s179`, `t600:s180`, `t600:s181`, `t600:s182`, `t600:s183`, `t600:s184`, `t600:s185`, `t600:s186`, `t600:s187`, `t600:s188`, `t600:s189`, `t600:s190`, `t600:s191`, `t600:s192`, `t600:s193`, `t600:s194`, `t600:s195`

Original: 一个封闭，这个封闭是被其实它是被外面的给它包裹起来的，它封闭他妈了吧子的，它不是它不是一开始就没有内在啊，它就是它是被被绝对者封闭出来的，被做出来的一个封闭性的一个东西啊，这是一个reflected，就其实being它是个intself或者它是一个immediacy啊，不加中介非中介性啊，但是它又是一个被reflected，就是被炮制出来的这这种东西呢啊，它所以它加了一个啊加了一句这个东西，它在它的otherness当中，在它的otherness当中或者说它otherness就是什么叫什么叫它的otherness啊，因为它是一个being，所以我们像它being是什么意思？就是它是个otherness，就对于essence对于理智来言，它是个otherness，它是被我打包起来封闭起来东西，封闭之后里面是啥我不知道了，就是这个cause好像它是个密闭的一个东西了，所以它是个otherness，我对词里面的东西不知了，故意不知道的你知道吗？故意把它封闭起来了啊，哦他在他的这种他异性当中或者说在他的啊或者说作为一个指非中介者啊，or asimmediate不被中介的一个东西，它behaves它本质性的essentially就是因为它是个reflectedbeing啊，它是个reflectedbeing，它是一个高阶existence你知道吗？它是个高阶高阶的就是高阶的一个一个一个模组的，就是自己把它实际上是你妈的是敞开的呀，但是我把它封装起来，我说他妈的它是一个脱离的封闭的，是一个意在的一个东西，我把它炮制成这么一个东西啊，就叫cosolidity啊，它这个cause就是这么一种东西嘛，cause就是这种东西，所以它本质性的，这个是本，实际上它是一个本质论的装置，它是个本质论的装置，本质论里面才会有这种装置，本质论里面就会有这种装置啊，或者其实实存论里面就会有这种，其实好多环节里面都会有这种装置，故意做一个东西，这个东西呢又说不是我做的，他自己就是他自己，就这么一种这么一个技巧。

Edited: 一个封闭——这个封闭其实是被外面的东西给它包裹起来的；它不是一开始就没有内在，它是被绝对者封闭出来的，是被做出来的一个封闭性的东西。这是一个 reflected；其实 being 是个 in itself，或者它是一个 immediacy，不加中介、非中介性，但是它又是一个被 reflected、被炮制出来的东西。所以它加了一句：这个东西在它的 otherness 当中——或者说它的 otherness。什么叫它的 otherness？因为它是一个 being。它 being 是什么意思？就是它是个 otherness；对于 essence、对于理智而言，它是个 otherness，它是被我打包起来、封闭起来的东西。封闭之后里面是啥，我不知道了。就是这个 cause 好像是个密闭的东西了，所以它是个 otherness，我对这里面的东西不知了——故意不知道的，你知道吗？故意把它封闭起来了。他在他的这种他异性当中，或者说作为一个非中介者，or as immediate，不被中介的一个东西，它 behaves，它本质性地、essentially 就是因为它是个 reflected being；它是个 reflected being，它是一个高阶 existence，你知道吗？它是个高阶的、高阶的一个模组。就是自己把它——实际上它是敞开的呀，但是我把它封装起来，我说它是一个脱离的、封闭的，是一个意在的东西，我把它炮制成这么一个东西，就叫 cosolidity。它这个 cause 就是这么一种东西嘛，cause 就是这种东西。所以它本质性的——实际上它是一个本质论的装置，它是个本质论的装置；本质论里面才会有这种装置。或者其实实存论里面就会有这种，其实好多环节里面都会有这种装置：故意做一个东西，这个东西又说不是我做的，他自己就是他自己，就这么一种技巧。

- “意在”转写不确定，疑为“异在”；正文保留原词。; 异在; t600:s191
- 术语转写不确定，疑为 solidity 或 co\-solidity；正文保留原词。; solidity/co\-solidity; t600:s191

## Paragraph 30: 1288975–1363375 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1288)

Segments: `t600:s196`, `t600:s197`, `t600:s198`, `t600:s199`, `t600:s200`, `t600:s201`, `t600:s202`, `t600:s203`, `t600:s204`

Original: 那么这个东西呢，它本质性的必然会是一个positioningactivity，设定性的活动性，就把就把它设定在那边，实际上是把它风中弄在那边一个东西，然后通过它的否定中介他自己，and through its negation,mediatesitself，然后通过它的否定，实际上是中介它自身，实际上我们是理解了它，我们才理解了它，中介了它，我们通过它的否定，我中介了它，我不是直接中介它，我理解它就是他妈的就是我理解就是理解它的不可理解性，你懂吗？我中介它就是中介它不可中介性嘛，就叫through its negation,mediatesitself，或者说这个东西通过它的否定中介它自己，我们就是这个东西它中介了它自己，这个东西它的否定是什么？its negation是什么？its negation就是its otherness to me嘛，或者说its negative as negative to to to to theabsolute，对于绝对者而言，你明白了吗？就好烦，是好烦，但是你熟悉这个思维方式就不烦了。啊，here therefore causality no longer has a substrate in which itinherits，啊在这里因此呢，啊原因性或起因性啊再也不具有一个啊再也不具有一个substrate，no longer has substrate in which it

Edited: 那么这个东西，它本质性地必然会是一个 positioning activity，设定性的活动性，把它设定在那边——实际上是把它封冻在那边一个东西——然后通过它的否定中介他自己，and through its negation mediates itself。然后通过它的否定，实际上是中介它自身；实际上我们是理解了它，才理解了它、中介了它。我们通过它的否定中介了它；我不是直接中介它。我理解它，就是理解它的不可理解性，你懂吗？我中介它，就是中介它的不可中介性嘛，就叫 through its negation mediates itself。或者说，这个东西通过它的否定中介它自己；它中介了它自己。这个东西它的否定是什么？its negation 是什么？its negation 就是 its otherness to me，或者说 its negative as negative to the absolute，对于绝对者而言。你明白了吗？就好烦，是好烦，但是你熟悉这个思维方式就不烦了。Here therefore causality no longer has a substrate in which it inherits；在这里，因此，原因性或起因性再也不具有一个 substrate，no longer has a substrate in which it inherits。

- “风中弄”转写不确定，正文暂作“封冻”，语义可能为封装/封冻。; 封冻/封装; t600:s197

## Paragraph 31: 1363375–1483712 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1363)

Segments: `t600:s205`, `t600:s206`, `t600:s207`, `t600:s208`, `t600:s209`, `t600:s210`, `t600:s211`, `t600:s212`, `t600:s213`, `t600:s214`, `t600:s215`, `t600:s216`, `t600:s217`, `t600:s218`, `t600:s219`

Original: inherits，它就不再具有一个机制，它是住在里面的了，它这个飘离的，懂吗？它是飘离的啊，in which itinherits，它就没有一个说居住在其中，就就内内附在其中的一个一个一个机制了。It is not a determination form as against the its identity,but is itself substance\.Causality这个东西呢，它就再也不是一个啊形式的一个规定，它不再是一个形式规定啊啊，好像是对立于这么一种同一性啊，对立于thisidentity，对立于同一性，就同一性就是这个substrate和这个causality是一并一个的啊一并一个的，它不再是一个形式规定性，它的对立这个啊but is itselfsubstance，啊它不是就是说就在这里这个原因，因为它本来是个形式规定，然后对立于这个同一性substrate和这个causality的同一关系，它对立于此。如果如果是这样的话，我们就又回到前面去了啊，这里说这个这个状态这个状况，it is not a determination of form as against thisidentity，这个状况指的并不是现状，这个状况就是说如果它是个determination of form as against this identity。它只是说形式因果性和规定啊确定因果性的一个对立，确定因果性determineate这个它这一直贯穿的这种啊这个这个对立的，but is itselfsubstance，这个时候causality自己就变成substance了啊，is a passive substance which causality has presupposed foritself，然后这个啊it is not determination for myself，but is itself caussubstance，这个时候causality本身就会被看成是实体，我们进一步运动causality本身被看成是一种实实

Edited: 它就不再具有一个机制，它是住在里面的了，它这个飘离的，懂吗？它是飘离的——in which it inherits；它就没有一个居住在其中、内附在其中的机制了。It is not a determination of form as against this identity, but is itself substance。Causality 这个东西呢，它就再也不是一个形式的规定，不再是一个形式规定，好像是对立于这么一种同一性，对立于 this identity，对立于同一性；同一性就是这个 substrate 和这个 causality 是一并一个的。它不再是一个形式规定性；它的对立——but is itself substance。它不是就是说……就在这里这个原因，因为它本来是个形式规定，然后对立于这个同一性：substrate 和这个 causality 的同一关系，它对立于此。如果是这样的话，我们就又回到前面去了。这里说这个状态、这个状况：it is not a determination of form as against this identity。这个状况指的并不是现状；这个状况就是说如果它是个 determination of form as against this identity。它只是说形式因果性和规定、确定因果性的一个对立，确定因果性（determinate）——它这一直贯穿的这种对立——but is itself substance；这个时候 causality 自己就变成 substance 了，is a passive substance which causality has presupposed for itself。然后这个……it is not determination for myself, but is itself caus—substance；这个时候 causality 本身就会被看成是实体。

- “determineate”转写不确定，正文暂作 determinate。; determinate; t600:s216
- “caus—substance”处转写不完整，疑为 causality as substance 或 causality/substance；正文保留不确定形态。; causality as substance; t600:s218, t600:s219

## Paragraph 32: 1483712–1524192 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1483)

Segments: `t600:s220`, `t600:s221`, `t600:s222`, `t600:s223`, `t600:s224`, `t600:s225`, `t600:s226`

Original: 体啊，或者换句话说，单单就靠这个causality，单单靠起因性本身它就是本身它就是起源了，它就是源头，is at theorigin，一开始一开始就是纯的起因性，纯的causality，一开始那个东西就不叫做实体了，我们也不叫就就把它叫做causality as asubstance啊，就是the the first cause the first cause，the substance the substrate is apassive substance which causality has presupposed foritself，这个时候这个这个时候我们就可以说啊

Edited: 或者换句话说，单单就靠这个 causality，单单靠起因性本身，它就是起源了，它就是源头，is at the origin。一开始就是纯的起因性、纯的 causality；一开始那个东西就不叫做实体了，我们也不把它叫做……就把它叫做 causality as a substance，就是 the first cause，the first cause。the substance、the substrate is a passive substance which causality has presupposed for itself。这个时候我们就可以说……

## Paragraph 33: 1525552–1626192 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1525)

Segments: `t600:s227`, `t600:s228`, `t600:s229`, `t600:s230`, `t600:s231`, `t600:s232`, `t600:s233`, `t600:s234`, `t600:s235`, `t600:s236`, `t600:s237`, `t600:s238`, `t600:s239`, `t600:s240`, `t600:s241`, `t600:s242`

Original: 它有这个机制啊causality可以有这个substrate，这个机制是一个是一个被动的实体，而这个causality它自己则是一个efficientsubstance，causality自己说我是一个efficientsubstance，而静态的这个cause是一个passivesubstance啊，静态的cause就是呃或者说这个causality的它的载体，这个这个substrate可以翻译成载体或者它的机制，载体就是passivesubstance，因为前面我们讲的那个什么cause啊，前面的cause其实前面这个cause其实就是指的就是这个substrate of thecausality，它就是passivesubstance，而causality本身呢则是一个active活动性的实体，或者说efficient啊substance，就有两种实体两种实体，这个实体就分成两侧，一侧是passive的一侧是efficient的啊，一侧代表cause，一侧代表causality，一侧代表substrate，一侧代表substance本身了啊substance本身真正的那个substance，this cause nowacts，那么这么一个原因呢，它现在就会行动，这个结合到一块去，现在结合到一起去把它叫做一个cause，它就就会行动，for it is negative power overitself啊，因为它是啊对它自身的一个否定性的力量，它是对它自身的否定性的力量，它不是我I am not passive，I am notpassive，所以它可以act，at the sametime呢，那同时呢it is its ownpresupposition，它同时又是它自己的一个预设，它自己又是它自己的一个预设，它是它自己的前提。

Edited: 它有这个机制：causality 可以有 substrate。这个机制是一个被动的实体，而 causality 自己则是 efficient substance。Causality 自己说“我是一个 efficient substance”，而静态的 cause 是一个 passive substance。静态的 cause，或者说 causality 的载体——这个 substrate 可以翻译成“载体”，或者它的“机制”——载体就是 passive substance。因为前面我们讲的那个 cause，其实指的就是 substrate of the causality，它就是 passive substance。而 causality 本身则是一个活动性的实体，或者说 efficient substance。所以就有两种实体，实体分成两侧：一侧是 passive，一侧是 efficient；一侧代表 cause，一侧代表 causality；一侧代表 substrate，一侧代表 substance 本身，真正的那个 substance。This cause now acts：这么一个原因现在就会行动。结合到一块去，现在把它叫做一个 cause，它就会行动，for it is negative power over itself——因为它是对于自身的一个否定性的力量，它是对自身的否定性的力量。它说：I am not passive，I am not passive，所以它可以 act。At the same time，同时它 it is its own presupposition：它同时又是它自己的一个预设，它自己又是它自己的一个预设，它是它自己的前提。

## Paragraph 34: 1627138–1670018 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1627)

Segments: `t600:s243`, `t600:s244`, `t600:s245`, `t600:s246`, `t600:s247`, `t600:s248`

Original: 它是它自己的前提，它它必须存在为它自己的前提。哦，它在前面它是一个自己设定性的一个活动性，所以它这个时候把自己设定出来了，把自己设定出来了，好吧？原因性是一个这种活动性，那么cause由于它其实就是这个这个causality设置出来一个substrate或者说一个passivesubstance，然后变成这个cause，这个cause上面呢它那个否定性的力量指向它自己，其实就通通都是它自己玩的啊。At the sametime，那同时呢它就是它自己的一个前提，它自己把自己作为前提设立出来。

Edited: 它是它自己的前提，它必须存在为它自己的前提。它在前面是一个自己设定性的活动性，所以这个时候它把自己设定出来了，把自己设定出来了，好吧？原因性是一种这种活动性。那么 cause 由于它其实就是这个 causality 设置出来的一个 substrate，或者说一个 passive substance，然后变成这个 cause；这个 cause 上面，它那个否定性的力量指向它自己。其实通通都是它自己玩的。At the same time，同时它就是它自己的一个前提，它自己把自己作为前提设立出来。

## Paragraph 35: 1670658–1696978 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1670)

Segments: `t600:s249`, `t600:s250`, `t600:s251`, `t600:s252`, `t600:s253`, `t600:s254`

Original: 因为你要说有一个efficient呃这个power或者efficient这个activity或者substance，你得先有一个它施加在什么上面嘛？它施加在什么上面？它施加在什么上面？就好像这么一个惰性的东西它开始行动了，就是这么个意思，就是说这个时候原因就会把自己变成这个由静到动的一个过程。它本来是个惰性东西，passive的一个东西，上面有一个活跃的力量行动起来了。

Edited: 因为你要说有一个 efficient power，或者 efficient activity，或者 substance，你得先有一个它施加在什么上面的东西，对吧？它施加在什么上面？它施加在什么上面？就好像这么一个惰性的东西开始行动了，就是这么个意思：这个时候原因就会把自己变成由静到动的一个过程。它本来是个惰性东西、passive 的东西，上面有一个活跃的力量行动起来了。

## Paragraph 36: 1697458–1759858 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1697)

Segments: `t600:s255`, `t600:s256`, `t600:s257`, `t600:s258`, `t600:s259`, `t600:s260`, `t600:s261`

Original: 啊那个，那么这这一整个整体是它自己的前提，或者说那个将死的被动的那些部分就是它的前提，是它的前提。它先得有将死的这部分passive那一部分，然后再开始动起来，它就把这个passive这部分设定成它的前提。因此呢，it acts upon as uponanother，所以它啊acts uponitself，它是对于自己起作用，就好像对于啊它一个它的起作用一样，这个叫自因性，这个就你理解什么叫自因性了，就是一因就有自因性啊，自己对自己自己把自己驱动起来，就像头拽着自己头发把自己拽出沼沼泽，它就好像啊施加这个行动在自己身上，就好像行动在一个它的身上，这个它的就是一个就其passive就其passive而言啊upon the passivesubstance啊，就是施加在那个啊那个那个那个被动性的实体上面。

Edited: 那么这一整个整体是它自己的前提，或者说那个僵死的、被动的那些部分就是它的前提。它先得有僵死的这部分、passive 那一部分，然后再开始动起来，它就把 passive 这部分设定成它的前提。因此，it acts upon as upon another，所以它 acts upon itself：它是对于自己起作用，就好像对于另一个它起作用一样。这个叫自因性，这就是你理解什么叫自因性了。一个因就有自因性：自己对自己，自己把自己驱动起来，就像头拽着自己头发把自己拽出沼泽。它就好像把这个行动施加在自己身上，就好像行动在一个“它”的身上；这个“它”就是就其 passive 而言，upon the passive substance，就是施加在那个被动性的实体上面。

- “将死”疑为“僵死”或类似表述。; 僵死; t600:s255, t600:s256

## Paragraph 37: 1760258–1786338 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1760)

Segments: `t600:s262`, `t600:s263`, `t600:s264`, `t600:s265`, `t600:s266`, `t600:s267`

Original: 因此呢，at first supplants otherness of this substance and returns it back to itself。它起先它扬弃了啊这种实体的一个差异性，它好像就初步扬弃了。这个first就可以find了，它初步扬弃了它的这一种实体，这种被动的啊passive substance。这个passivesubstance还记得前面是什么？是一个reflective啊reflectivebeing啊，它是一个reflective being。

Edited: 因此，at first supplants otherness of this substance and returns it back to itself。它起先扬弃了这种实体的差异性，好像初步扬弃了。这个“first”就可以看出来了：它初步扬弃了它的这一种实体，这种被动的 passive substance。这个 passive substance 还记得前面是什么吗？是一个 reflective being。

- 引文中的“supplants”疑为“sublates”（扬弃）。; sublates; t600:s262
- 原文“find”含义不确定，此处按“看出／找到”理解。; 看出来; t600:s264

## Paragraph 38: 1786898–1829091 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1786)

Segments: `t600:s268`, `t600:s269`, `t600:s270`, `t600:s271`, `t600:s272`, `t600:s273`, `t600:s274`, `t600:s275`

Original: 这个东西是个很矬的一个装置，对不对？你们本质论没有学过，我直接给你讲这个啊，这其实这还是本质论啊，所以你理解这个东西不太好理解。他妈的，本质论看多了，你知道这个屌东西到处都是啊，reflectivebeing到处都是，特别是你从actuality开始，全是你妈reflectivebeing啊，possibility啊都是reflective being。很垃圾的玩意，就是它就是一个这脚迹，你知道吗？就是reflecting，就是说，其实我都懂，但是我故意装了不懂。这个东西是我故意装了不懂的一个我不懂的东西，就这这么个屌东西啊，就是这么一个屌东西，它就好像是一个存在，它不是它不是本质，

Edited: 这个东西是个很矬的装置，对不对？你们本质论没有学过，我直接给你讲这个——这其实还是本质论，所以你理解这个东西不太好理解。他妈的，本质论看多了，你知道这个屌东西到处都是：reflective being 到处都是，特别是你从 actuality 开始，全是你妈 reflective being；possibility 也都是 reflective being。很垃圾的玩意，它就是一个脚迹，你知道吗？就是 reflecting。就是说，其实我都懂，但是我故意装了不懂。这个东西是我故意装了不懂的一个我不懂的东西，就是这么个屌东西；它就好像是一个存在，它不是本质，不是一种反思，不是一种思维，它好像是个存在。

- “脚迹”疑为“痕迹／踪迹”或类似词。; 痕迹; t600:s273

## Paragraph 39: 1829091–1876611 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1829)

Segments: `t600:s276`, `t600:s277`, `t600:s278`, `t600:s279`, `t600:s280`, `t600:s281`

Original: 不是个不是一种反思，不是一种思维，它好像是个存在啊，但是它实际上是已经被我反思过的，我就谋篇布局当中，我故意搞出这么个假的，偏偏我自己的一个小小东西，偏为什么要骗自己？因为用用一个谎言来解决之前那个谎言，我前面那个谎言圆谎，前面的谎言就是我是大哥，你前面的这些偶性全是小弟，你偶性性指向的是我大哥，但实际上是个谎言，那就只有他妈的前台的偶性，懂吗？他要为前面这个谎言圆谎，圆谎说啊，这之间有个形式因果性，然后再再搞有个确定的因果性，然后一步一步的不停的圆谎，对吧？黑格尔就是什么逻辑学就是这么一个过程，很挫的啊，实事求是的讲。哎，我们讲哪里啊？

Edited: 但是它实际上是已经被我反思过的；在谋篇布局当中，我故意搞出这么个假的、偏偏是我自己的一个小小东西。为什么要骗自己？因为要用一个谎言来解决之前那个谎言，为前面的谎言圆谎。前面的谎言就是“我是大哥，你前面的这些偶性全是小弟，你偶性指向的是我大哥”，但实际上是个谎言，那就只有他妈的前台的偶性，懂吗？他要为前面这个谎言圆谎，说这之间有个形式因果性，然后再搞出个确定的因果性，然后一步一步不停地圆谎，对吧？黑格尔的逻辑学就是这么一个过程，很挫的，实事求是的讲。哎，我们讲到哪里了？

- “前台的偶性”语义不明，疑为“前提的偶性”或其他表述。; 前提; t600:s279

## Paragraph 40: 1876691–1944131 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1876)

Segments: `t600:s282`, `t600:s283`, `t600:s284`, `t600:s285`, `t600:s286`, `t600:s287`, `t600:s288`, `t600:s289`, `t600:s290`, `t600:s291`, `t600:s292`

Original: 啊，然后就说，他他这起初他就扬，好像扬弃了这个实体的它的那种啊，它的那个他异性，然后returns it back toitself，然后把这个东西returns in it back toitself，然后它在这个实体当中好像回到了它自身，好像回到它自身啊，就是这个活动性或者原因好像回到它自己，好像哇，就好像回家了一样，就是cause在它的这个里面，在它的这个passive substance里面，它好像又重新重振雄风了。I am我又哎，这个cause可以说I am againcausality，我又变成causality了，看上去啊，看上去第一步起初看上去它好像又回到它自己，我这个cause又是一个活生生的一个东西了，又是一个又是一个就是牵引的一个力量了，那种originating的一个力量了。然后第二步呢，it determines this same substance possesses sublation of its otherness or the substance turning back into itself as determinateness。

Edited: 然后就说，他起先好像扬弃了实体的那种他异性，然后 returns it back to itself；然后把这个东西 returns it back to itself，然后它在这个实体当中好像回到了它自身——这个活动性或者原因好像回到它自己，好像回家了一样。就是 cause 在它的这个 passive substance 里面，好像又重新重振雄风了。I am again causality：我又变成 causality 了。看上去，第一步起初看上去它好像又回到它自己；我这个 cause 又是一个活生生的东西了，又是一个牵引的力量，那种 originating 的力量了。然后第二步呢，it determines this same substance possesses sublation of its otherness or the substance turning back into itself as determinateness。

## Paragraph 41: 1945891–1998432 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1945)

Segments: `t600:s293`, `t600:s294`, `t600:s295`, `t600:s296`, `t600:s297`, `t600:s298`, `t600:s299`, `t600:s300`

Original: 但是第二步呢，第二步它又规定了这么一个在同一个实体，它要把这个同一个实体加以规定啊，它又把它加以一个明确化，this substance怎么规定它呢？就是说它把对于这个东西的他异性的一个扬弃，或者说啊，它就设定出对于这个东西的一个他异性的扬弃啊，或者说它就设定出一个这个实体本身是the substance turning back into itself asdeterminateness，这个实体这么一个实体这么一个passivesubstance，它转回它自己是一个是它的一个determinateness。是它的一个确定状态，是它的一个明确的状态，确定状态啊，posits or the thesublation啊，他又把这个东西给它设定下来，又设定下来啊。

Edited: 但是第二步呢，第二步它又规定了这同一个实体，它要把这同一个实体加以规定，把它明确化。这个 substance 怎么规定它呢？就是说，它把对于这个东西的他异性的扬弃设定出来；或者说，它就设定出这个实体本身是 the substance turning back into itself as determinateness。这个 passive substance 转回它自己，是它的一个 determinateness，是它的一个确定状态、明确的状态。posits or the sublation，它又把这个东西设定下来。

## Paragraph 42: 1998752–2047232 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=1998)

Segments: `t600:s301`, `t600:s302`, `t600:s303`, `t600:s304`, `t600:s305`, `t600:s306`

Original: 那么接下来看嘛，这种啊，这种呃被设定性啊，或者说这种被设定状态，because it is at seven times substance turning back into itself is at first itseffect啊，就是它的效果啊，就是起先是它的效果，起先就是它的效果。这里怎么理解呢？就是说第二步它规定了是同一个实体，它又规定这同一个实体，规定这同一个实体啊，把它变成一种规定状态，变成一种规定状态，明一个明确状态。就这个东西呢，你是看的就是前面一步，它好像这cause在这里面，哎，我把它牵引起来了，我操，我这个活跃的那部分，把这个被动那一部分给它牵引起来了，把它牵引起来了。

Edited: 那么接下来看，这种被设定性，或者说这种被设定状态，because it is at seven times substance turning back into itself is at first its effect，就是它的效果，起先就是它的效果。这里怎么理解呢？就是说，第二步它规定了是同一个实体，它又规定这同一个实体，把它变成一种规定状态、一种明确状态。这个东西，你看到的是前面一步：它好像这 cause 在这里面，我把它牵引起来了——我操，我这个活跃的那部分，把被动那一部分给它牵引起来了。

- “at seven times”语义不明，疑为“at first”或类似表述。; at first; t600:s301

## Paragraph 43: 2048752–2117712 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2048)

Segments: `t600:s307`, `t600:s308`, `t600:s309`, `t600:s310`, `t600:s311`, `t600:s312`, `t600:s313`, `t600:s314`

Original: 那么第二步立刻就要把这个对于它的这个阳气给它设定下来，就是说我虽然好像我在这个，就是就是第一步他说我重新是我自己的，第二步就是说我你被我打败了，听懂这个意思吗？就是说第一步起先他好像回到他自身，但是第二步他立刻他他就是说不甘于仅仅回他自身了，他又立刻又跑出来说你这个东西被我打败了，我是通过打败你才回到我自身的，我是通过激活你才回到我自身的。啊，他要把这么一个对于这个东西的这么一个被动的实体的他异性的阳气给它设定出来，给它设定出来。其实他回不回自身不重要，他回回回不回他自身其实并不是他的主要目的，他主要的目的是说我是通过干掉你我才回到我自身的，我是通过干掉你我才从一个cause重新变成causeolated，我是通过克服了我的惰性啊，其实是克服了他自己的惰性，或者克服了这么一个被动的实体，我才我才活跃起来的。

Edited: 那么第二步，立刻就要把这个——对于它的这个阳气——给它设定下来。也就是说，虽然我在第一步好像重新成为我自己的，但第二步就是说：你被我打败了，听懂这个意思吗？第一步起先他好像回到他自身，但第二步他立刻就不甘于仅仅回到他自身了，他又立刻跑出来说：你这个东西被我打败了；我是通过打败你才回到我自身的，我是通过激活你才回到我自身的。啊，他要把这么一个对于这个东西的、这么一个被动的实体的他异性的阳气，给它设定出来，给它设定出来。其实他回不回自身并不重要，回不回他自身并不是他的主要目的；他主要的目的是说：我是通过干掉你才回到我自身的，我是通过干掉你才从一个 cause 重新变成 causality，我是通过克服了我的惰性——其实是克服了他自己的惰性，或者克服了这么一个被动的实体——我才活跃起来的。

- “阳气”疑为“扬弃”（sublation）的误转写; 扬弃; t600:s307
- “causeolated”疑为“causality”的误转写; causality; t600:s313

## Paragraph 44: 2118112–2191955 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2118)

Segments: `t600:s315`, `t600:s316`, `t600:s317`, `t600:s318`, `t600:s319`, `t600:s320`, `t600:s321`, `t600:s322`, `t600:s323`, `t600:s324`

Original: 其实他不是为了活跃起来，他的目的是为了表明那个惰性被他克服，或者他表明他啊，哦，他要把这个substance要把这个实体本身的转回到他自身，实体本身的回转回自身看成是一个明确状态，他要把这个东西给它规定下来。这里发生了一件什么事儿？什么东西是很明确的一个东西，一个一个状况在这里发生的是啥？是这个被动的实体它转回它自己了啊，turning back intoitself，转回它它自自己了啊，我把它阳气掉了，我把它阳气掉了，这个玩意儿也消失了，这个东西它是个被动东西，我把这个对于它的这种被动性、惰性这种他异性给阳气掉了，也就是说要响亮的把这个对他的阳气给他说出来，你就是说，也这你看见吧？This所以这种啊，这种被设定状态，这种positiveness啊，because it is at the same time the substance turn back intoitself，由于它同时是这个实体的转回到它自身，实体回转它的自身，is at first its

Edited: 其实他不是为了活跃起来，他的目的是为了表明那个惰性被他克服，或者表明——他要把 substance、把这个实体本身的转回到它自身，把实体本身的回转回自身看成是一个明确状态，他要把这个东西规定下来。这里发生了一件什么事儿？什么东西是很明确的一个东西？一个一个状况在这里发生的是啥？是这个被动的实体它转回它自己了——turning back into itself，转回它自己了。我把它阳气掉了，我把它阳气掉了，这个玩意儿也消失了；这个东西是个被动东西，我把对于它的这种被动性、惰性这种他异性给阳气掉了。也就是说，要响亮地把对他的阳气给他说出来：你就是说，也这你看见吧？This——所以这种被设定状态，这种 positiveness，because it is at the same time the substance turn back into itself，由于它同时是这个实体的转回到它自身，实体回转它的自身，is at first its effect。

- “阳气”疑为“扬弃”的误转写; 扬弃; t600:s321
- “positiveness”疑为“positedness”的误转写; positedness; t600:s323

## Paragraph 45: 2192036–2292676 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2192)

Segments: `t600:s325`, `t600:s326`, `t600:s327`, `t600:s328`, `t600:s329`, `t600:s330`, `t600:s331`, `t600:s332`, `t600:s333`, `t600:s334`, `t600:s335`, `t600:s336`, `t600:s337`

Original: effect，所以看上去是它的效果，好像看上去是它的效果，啊，看上去就是说，哎，好像就是我这个cause在成为cosolity的过程当中起到一个效果，就是让这个让这个让这个passivesubstance被我阳气掉了，啊，passivesubstance被我阳气掉了，或者说我让这个substance回转我回转回自身啊，让这个实体回转到它自身，实体又动起来了，实体返回到它自己了，我让这个实体又运动起来了，我让这个实体的谋篇布局又开始动起来了，它不再是一个passivesubstance了，听懂了吧？我让这个实体又开始按照它的那个谋篇布局又开始运动起来了啊，又转回到自身去了，不让这个实体摆脱了它在那个一个reflectedbeing当中啊茫然自失的那种啊那种那种那种迷惑状态或者那种呃嗯就自我遗忘的那种状态，就是卡在那边，我它不卡住了，继续跑起来了，然后回到它自身了，所以它就是啊就是它的效果，它的效果就是说这个时候就是说它的效果，这个cause啊就克服这个passivesubstance变成cosolity，好像是它回到自身，但是其实它不是它回到自身，他说我又让实体又回到它自己了，又让实体又转起来又动起来，我的效果就是这个，但是反过来说呢，but conversely conversely because as presupposing it determines itself as its other it then produces effect in this other in the passive

Edited: 所以看上去是它的效果，好像看上去是它的效果。啊，看上去就是说：哎，好像就是我这个 cause 在成为 causality 的过程当中起到一个效果，就是让这个 passive substance 被我阳气掉了；啊，passive substance 被我阳气掉了，或者说我让这个 substance 回转回自身——让这个实体回转到它自身，实体又动起来了，实体返回到它自己了，我让这个实体又运动起来了。我让这个实体的谋篇布局又开始动起来了，它不再是一个 passive substance 了，听懂了吧？我让这个实体又开始按照它的那个谋篇布局又开始运动起来了，又转回到自身去了，不让这个实体摆脱了它在那个 reflected being 当中茫然自失的那种迷惑状态，或者那种自我遗忘的状态——就是卡在那边；我不让它卡住了，继续跑起来了，然后回到它自身了。所以它就是它的效果；它的效果就是说，这个时候这个 cause 就克服这个 passive substance，变成 causality；好像是它回到自身，但其实不是它回到自身，他说我又让实体又回到它自己了，又让实体又转起来、又动起来。我的效果就是这个。但是反过来说呢，but conversely, conversely, because as presupposing it determines itself as its other, it then produces effect in this other, in the passive substance。

- “阳气”疑为“扬弃”的误转写; 扬弃; t600:s327
- “cosolity”疑为“causality”的误转写; causality; t600:s336
- 此处“不让”与上下文语义略矛盾，是否应为“让”不确定; 让; t600:s333

## Paragraph 46: 2292755–2362097 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2292)

Segments: `t600:s338`, `t600:s339`, `t600:s340`, `t600:s341`, `t600:s342`, `t600:s343`, `t600:s344`, `t600:s345`, `t600:s346`, `t600:s347`, `t600:s348`, `t600:s349`, `t600:s350`, `t600:s351`, `t600:s352`

Original: substance，但是由于呢作为由于原因啊，或者说由于这个因果性，就是成为原因的这种蛇皮因果性啊，这个他妈的是一个一个演很狡猾的戏的一个一个家伙，这个这个蛇皮因果性它作为一个预设活动，它怎么样？它规定它自己作为它的他者determines itself as itsother啊，它规定它自身作为它的他者，规定成什么了？determinesitself规定什么？规定成cause嘛？规定成passive passivesubstance加载在一个passivesubstance以passivesubstance作为substrate的一个cause嘛？啊，所以呢，它又把这个效果in thisother又把这个效果设定下来，设定在这么一个他者当中，设定在这个他者就是设定在cause里面，又把effect效果设定在cause里面，你看这只有在这个cause里面作为这个啊，作为这个causeact，这个cause本身就是一个被动和主动的一个结合体啊，结合嵌合体，我觉得substance passivesubstance和这个efficientsubstance两个结合到一起去的一个东西，

Edited: 但是由于，作为——或者说由于原因，或者说由于这个因果性，就是成为原因的这种蛇皮因果性——这个他妈的是一个很狡猾的戏的一个家伙。这个蛇皮因果性它作为一个预设活动，它怎么样？它规定它自己作为它的他者，determines itself as its other；它规定它自身作为它的他者，规定成什么了？determines itself 规定什么？规定成 cause 嘛？规定成 passive substance？加载在一个 passive substance，以 passive substance 作为 substrate 的一个 cause 嘛？啊，所以呢，它又把这个效果 in this other 又把这个效果设定下来，设定在这么一个他者当中，设定在这个他者——就是设定在 cause 里面，又把 effect、效果设定在 cause 里面。你看，这只有在这个 cause 里面，作为这个 cause act，这个 cause 本身就是一个被动和主动的结合体、结合嵌合体，我觉得是 passive substance 和这个 efficient substance 两个结合到一起去的一个东西。

- “蛇皮因果性”为口语化/不确定表述，所指可能是“狡猾的因果性”; 蛇皮因果性; t600:s339

## Paragraph 47: 2363297–2442017 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2363)

Segments: `t600:s353`, `t600:s354`, `t600:s355`, `t600:s356`, `t600:s357`, `t600:s358`, `t600:s359`, `t600:s360`, `t600:s361`, `t600:s362`, `t600:s363`, `t600:s364`, `t600:s365`, `t600:s366`, `t600:s367`

Original: 所以它这个时候这个效果啊，这种效果它是要夹杂的啊，它posit theeffect，这个theeffect就指的前面那个effect啊，前面那个effect，它的effect啊，它又把这个效果，这个效果就是那个结果，就是那个实体又回到它自己了，好了不起，嗯，应该是我克服了他的惰性，我作为一个原因，我帮他克服了他的惰性，我作为causality，我帮他克服了他的惰性，他又回到他自己，但是他只能把这个效果设定在他的他者当中，只能把它设定在cause里面，这个cause只能或者说只能把它设定在thisother里面，这个causality只能把这个effect，the effect of of what of that the substance is turning back toitself，把这个effect posits in哪里啊？in this other other是什么？other就是cause，那么这个cause是什么？cause就是the passivesubstance啊，passive substance must be actedupon啊，byby什么efficientsubstance这个东西啊，你必须还是能把这个效果啊，把这个效果设定在一个被动的一个实体当中，或者or again because the passive substance is itself this

Edited: 所以它这个时候这个效果，这种效果它是要夹杂的：它 posit the effect。这个 the effect 就指前面那个 effect，前面那个 effect，它的 effect；它又把这个效果——这个效果就是那个结果，就是那个实体又回到它自己了——好了不起，嗯，应该是我克服了他的惰性；我作为一个原因，我帮他克服了他的惰性；我作为 causality，我帮他克服了他的惰性，他又回到他自己。但是他只能把这个效果设定在他的他者当中，只能把它设定在 cause 里面；这个 cause 只能，或者说只能把它设定在 this other 里面。这个 causality 只能把这个 effect——the effect of what? of that the substance is turning back to itself——把这个 effect posits in 哪里啊？in this other。other 是什么？other 就是 cause；那么这个 cause 是什么？cause 就是 the passive substance。啊，passive substance must be acted upon，by by 什么？efficient substance，这个东西。啊，你必须还是能把这个效果设定在一个被动的实体当中。或者 or again because the passive substance is itself this double。

## Paragraph 48: 2442177–2566179 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2442)

Segments: `t600:s368`, `t600:s369`, `t600:s370`, `t600:s371`, `t600:s372`, `t600:s373`, `t600:s374`, `t600:s375`, `t600:s376`, `t600:s377`, `t600:s378`, `t600:s379`, `t600:s380`, `t600:s381`, `t600:s382`, `t600:s383`, `t600:s384`, `t600:s385`, `t600:s386`

Original: double，或者说啊反过来说呢啊，或者说换一种方式说，就是由于这么一个被动的实体，它本身就是这个加倍，什么的加倍呢？就是说namely a self subsistent other and at the same time something presupposed and already implicitly identical with the efficientcause，由于这个被动的实体呢，本身就是一个自我持，一方面它是个自我持存的一个他者，自身持存，它自己就是持存的一个他者，是个比影，另外一方面呢，它同时呢at the sametime它就是某个被预设的东西，这个被预设的东西，它是它同时又是其实又是就是causality预设的玩意了，就是诡计，他妈的就就是其实是我自己偷偷预设的，就这么意思，它又是某个被预设东西，所以它早就已经是隐秘的是等同于那个起作用的原因了，the efficientcause，或者说the efficientsubstance啊，由于这由于这因此呢，由于这个东西呢，the呃这个action of the passive substance istherefore啊itselfdouble，所以呢，那么个被动的实体的它的行动，因此它就是加倍的，它就是加倍的啊，它就是加倍的，它就本身就是加倍的啊，就是说现换句话说就是你可以理解成就是说这个被动实体。它它的行动就加倍了，它的行动加倍。一方面，它是你们这块它加倍加倍在哪里啊？It is at once both sublation of its determinators。它同时啊，既是对于它的那种呃规定状态或者说明确状态啊，它的那个这种determinators它的一个阳气，namely of its condition or the sublation of the self subsistence of the passivesubs呃substance。也就是说，对于它的条件的一个阳气啊，或者说对于那个啊这种被动的实体的自身实实存的一个阳气啊，它一方面是对于这个东西的阳气，就是把它驱动起来，把它驱动起来

Edited: 或者说啊，反过来说呢，或者说换一种方式说：就是由于这么一个被动的实体，它本身就是这个加倍——什么的加倍呢？namely a self\-subsistent other and at the same time something presupposed and already implicitly identical with the efficient cause。由于这个被动的实体呢，本身就是一个自我持——一方面它是个自我持存的一个他者，自身持存，它自己就是持存的一个他者，是个比影；另外一方面呢，它同时 at the same time 就是某个被预设的东西。这个被预设的东西，它同时又是其实又是 causality 预设的玩意了，就是诡计——他妈的，其实就是我自己偷偷预设的，就这么意思。它又是某个被预设的东西，所以它早就已经是隐秘地等同于那个起作用的原因了，the efficient cause，或者说 the efficient substance。啊，由于这个东西呢，the——这个 action of the passive substance is therefore itself double。所以呢，那么这个被动的实体的它的行动，因此它就是加倍的，它就是加倍的，它就是加倍的，它本身就是加倍的。换句话说，就是你可以理解成这个被动实体，它的行动就加倍了，它的行动加倍。一方面——它加倍在哪里啊？It is at once both sublation of its determinations——它同时啊，既是对于它的那种规定状态或者明确状态，它的那个这种 determinations 的一个阳气，namely of its condition or the sublation of the self\-subsistence of the passive substance。也就是说，对于它的条件的一个阳气，或者说对于那个这种被动的实体的自身实存的一个阳气；它一方面是对于这个东西的阳气，就是把它驱动起来，把它驱动起来。

- “比影”一词不确定，疑为误转写; 比影; t600:s371
- “阳气”疑为“扬弃”的误转写; 扬弃; t600:s383
- “determinators”疑为“determinations”的误转写; determinations; t600:s383

## Paragraph 49: 2567779–2618339 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2567)

Segments: `t600:s387`, `t600:s388`, `t600:s389`, `t600:s390`, `t600:s391`, `t600:s392`, `t600:s393`, `t600:s394`, `t600:s395`, `t600:s396`

Original: 啊，呃让它动起来，让它不陷在那一种determinators里面，或者这个condition不要翻译成条件的状况，对于它的状况的一个阳气，它状况什么？它是个passive的一个东西，是个selfsubsistence的一个东西，是一个啊是一个reflectedbeing，是一个僵死一个东西啊。一方面就是你把它操纵起来，把它动起来，这个cause把它动起来，其实这本来它就是个动的力量，你知道吗？它这个不动也是它动的设立出来一个假的不动，你懂吗？啊，所以它它同时一方面就阳气了这么一个假的不动了，假装他妈不再动的这么一个东西啊，这是就是它的一个状态，把它阳气了，把这个被动实存的这个自我实存状况给它阳气掉啊。

Edited: 要让它动起来，不要让它陷在那种 determinators 里面；或者，不要把 condition 翻译成“条件的状况”。就它的状况而言，所谓“扬弃”是要扬弃什么？它是个 passive 的东西，是个 self\-subsistence 的东西，是一个 reflected being，是一个僵死的东西。一方面，你把它操纵起来、把它动起来，这个 cause 把它动起来；其实它本来就是动的力量。它的不动也是由它的动所设立出来的假的不动。所以，它同时一方面扬弃了这么一个假的不动——假装不再动的这么一个东西——这就是它的状态；把它扬弃了，把这个被动实存的自我实存状况扬弃掉。

- determinators 疑为 determinations（规定）的转写/识别误差; determinations; t600:s387
- 此段原文的“阳气”疑为“扬弃”的转写/识别误差；正文按上下文统一作“扬弃”; 扬弃; t600:s388

## Paragraph 50: 2618339–2669379 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2618)

Segments: `t600:s397`, `t600:s398`, `t600:s399`, `t600:s400`, `t600:s401`, `t600:s402`, `t600:s403`, `t600:s404`

Original: 别人同时呢啊，and also in sublating its identity as it sublates the this sub substance the presupposing of itself that is the positing or supposing of itself as other。它同时呢，在阳气它的呃sublation it is both andalso在阳气它的同一性的时候啊，在阳气in sublating itsidentity在阳气它同一性的时候，asit它又啊它又阳气了什么？它又阳气了这个实体，阳气的一个实体啊，阳气这个实体本身，又阳气了个被动实体本身，又阳气了那一个它自身的一个之前的一个假设thepresupposing ofitself这个前面支撑presupposing。

Edited: 另一方面，同时，and also in sublating its identity as it sublates this substance, the presupposing of itself—that is, the positing or supposing of itself as other。它同时——it is both and also——在扬弃它的同一性的时候，在 sublating its identity 的时候，它又扬弃了什么？它又扬弃了这个实体，扬弃了这个实体本身，扬弃了被动实体本身，又扬弃了它自身之前的一个假设，the presupposing of itself，这个前面支撑的 presupposing。

## Paragraph 51: 2670019–2703358 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2670)

Segments: `t600:s405`, `t600:s406`, `t600:s407`, `t600:s408`, `t600:s409`

Original: 这Hegel在这里做文字游戏，就是你要把理解这个substance这个passivesubstance实际上就是这个因果性的一个自己给自己设定出来这个前面的做支撑物的一个东西，作为支撑物东西，相当于你要把自己头怎么拽出来，得有个有个东西可以踩嘛，要跳要可以要踩着东西，那个踩着那个东西是你预设出来的，所以它这用个之前支撑啊，它它把这个之前支撑的这个脚手架或者怎么样的一个东西啊，要给它阳气掉了。把这个实体、被动实体给它扬弃掉了。

Edited: Hegel 在这里做文字游戏。你要理解这个 substance，这个 passive substance 实际上就是因果性自己给自己设定出来的、在前面做支撑物的东西。作为支撑物，相当于你要把自己拽起来，总得有个东西可以踩；要跳，也要踩着东西，而那个踩着的东西是你预设出来的，所以它用“之前支撑”这个说法。它要把这个之前支撑的脚手架之类的东西扬弃掉，把这个实体、被动实体给它扬弃掉。

## Paragraph 52: 2703438–2724398 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2703)

Segments: `t600:s410`, `t600:s411`, `t600:s412`, `t600:s413`, `t600:s414`, `t600:s415`, `t600:s416`

Original: 在这个过程中，在它动的过程中，在cause，cause内在，cause在原因、起因，在就是causality把自己变成一个cause，把自己变成cause，就要把自己变成一个啊passivesubstance，同时是一个efficientsubstance的这么一个玩意儿。这个玩意儿就是打包起来就是一个cause。

Edited: 在这个过程中，在它动的过程中，在 cause 的内在……在原因、起因，在 causality 把自己变成一个 cause，把自己变成 cause，就要把自己变成一个 passive substance，同时是一个 efficient substance 的这么一个玩意儿。这个玩意儿打包起来就是一个 cause。

## Paragraph 53: 2724638–2731678 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2724)

Segments: `t600:s417`, `t600:s418`, `t600:s419`, `t600:s420`

Original: 那么这个东西就其是个passivesubstance而言，它是个它是initself，它是个being。前面都讲过了，我不想重复了啊。

Edited: 那么，这个东西就其是个 passive substance 而言，它是个 in itself，它是个 being。前面都讲过了，我不想重复。

## Paragraph 54: 2733118–2760958 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2733)

Segments: `t600:s421`, `t600:s422`, `t600:s423`, `t600:s424`

Original: 那么就是你一方面就是把那个东西的僵死性给它扬弃掉了，另外一方面也把这个需要架设一个脚手架本身给它扬弃掉了，把这个东西本身给它扬弃掉了，就不就认为它不存在了，你懂吗？不仅仅是说把它的那个啊它的那个被动实体的那个自我持存给它扬弃掉了啊，给它的状况给它，把它那种确定状态啊，或者说把它的那种状态给它扬弃掉了。

Edited: 那么，一方面你把那个东西的僵死性扬弃掉了；另外一方面也把需要架设一个脚手架本身扬弃掉了，把这个东西本身扬弃掉了，也就是不认为它存在了。不仅仅是把它的被动实体的自我持存扬弃掉，把它的状况、它的确定状态，或者说把它的那种状态扬弃掉。

## Paragraph 55: 2760958–2794078 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2760)

Segments: `t600:s425`, `t600:s426`, `t600:s427`, `t600:s428`, `t600:s429`

Original: 它也把这么一个它本身要啊预先支撑它自己，提前支撑它自己，搞一个东西说那个东西之前支撑着我，其实是骗人的，通通都是骗人，你知道吗？辩证法通通都是骗人。这个但是黑格尔会告诉你，这些骗人是本体论上必要的，没有这个东西根本不会有这些环节啊。That is thepositin神就是本体论的机制可以反反常识，就是你小朋友就不能理解，别烦了。That is the positin orsupposing啊，也就是说，

Edited: 它也把这么一个东西扬弃掉了：它本身要预先支撑自己、提前支撑自己，搞一个东西说“那个东西之前支撑着我”，其实是骗人的，通通都是骗人的。辩证法通通都是骗人。但是 Hegel 会告诉你，这些骗人在本体论上是必要的；没有这个东西，根本不会有这些环节。That is the positin——就是本体论的机制，可以反常识；小朋友不能理解，别烦了。That is the positin or supposing，也就是说……

- positin 疑为 positing；此处的“神”疑为“是”的转写/识别误差; positing; t600:s428

## Paragraph 56: 2796398–2822318 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2796)

Segments: `t600:s430`, `t600:s431`, `t600:s432`

Original: 他就把这么一个实体本身给扬弃掉了，把它自身的一个啊一个之前的一个支撑，主动支撑的这么一个这么一个行动给它取消掉了。也就是说，把那个啊他自己作为一个他者啊设定或者支撑他自己啊的这个主动过程啊做一个他者来设定自己，做一个他者来支撑自己，这两件事情就扬弃掉了，必须要做的，已经动起来了，不需要这两个东西了。

Edited: 也就是说，它把这么一个实体本身扬弃掉了，把它自身之前的一个支撑、主动支撑的这么一个行动取消掉了。也就是说，把它自己作为一个他者来设定、或者支撑自己的这个主动过程——做一个他者来设定自己、做一个他者来支撑自己——这两件事情扬弃掉了。必须要做的已经动起来了，不需要这两个东西了。

## Paragraph 57: 2822878–2848158 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2822)

Segments: `t600:s433`, `t600:s434`, `t600:s435`, `t600:s436`

Original: 那么通过这最后一个环节啊，through this last moment，the passive substance is preserved。那个被动的实体反而被保存了。黑格尔这里很有意思啊，通过最后这个环节，被动的实体反而被保存了，preserved is preserved。啊，这个词儿其实很有意思啊，反而被保存了，防腐保存起来，但是它就就死了，僵死了，就死掉了。

Edited: 那么，通过这最后一个环节，through this last moment, the passive substance is preserved。那个被动的实体反而被保存了。Hegel 这里很有意思：通过最后这个环节，被动的实体反而被保存了，preserved is preserved。这个词其实很有意思：反而被保存了，防腐保存起来，但是它就死了、僵死了、死掉了。

## Paragraph 58: 2848798–2893985 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2848)

Segments: `t600:s437`, `t600:s438`, `t600:s439`, `t600:s440`, `t600:s441`, `t600:s442`, `t600:s443`, `t600:s444`, `t600:s445`, `t600:s446`

Original: 之前它是一个活的东西嘛？之前实际上是一个活的东西，是个presupposing啊，之前它是个presupposing，presupposing闭合了变成一个in itself，initself，然后说它是个passive的一个玩意儿，它只是一个initself，不是，他就否定的说我不是一个for itself。你不准回看，不准回看，看穿我的把戏，不准看啊。然后这个东西就是一个有待被看，是有待被看的。你不让我看，我就另外一个东西来把你看了，就是这个把它设定一个他者，把它牵引起来，把它动起来了。啊，它就是一个self subsist subsistentother了，就是动起来了。啊，它是不准看，不准你去窥视它的一个，它只能它自己在它自己那儿里面好好的那个样子。

Edited: 之前它是一个活的东西嘛？之前实际上是一个活的东西，是个 presupposing；之前它是个 presupposing，presupposing 闭合了，变成一个 in itself。然后说它是个 passive 的玩意儿，它只是一个 in itself；不，他就否定地说：我不是一个 for itself。“你不准回看，不准回看，看穿我的把戏，不准看啊。”然后这个东西就是一个有待被看的，是有待被看的。你不让我看，我就用另外一个东西来把你看，就是把它设定为一个他者，把它牵引起来，把它动起来了。它就是 a self\-subsistent other，就是动起来了。它是不准看、不准你去窥视它的；它只能自己在它自己那里，好好的那个样子。

- 原文作 self subsist subsistent other，疑为 self\-subsistent other; self\-subsistent other; t600:s444

## Paragraph 59: 2895825–2935185 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2895)

Segments: `t600:s447`, `t600:s448`, `t600:s449`, `t600:s450`

Original: 啊，它反而呃，that first sublation of it appears in this respect at the same time also in this way，namely that only some determinations are sublated in it and its identity in the effect with efficient cause occurs in it externally。就是说，第一个对于它的第一个阳气啊，在这么一个在这一方面啊，就是the first sublation of it appears in thisrespect，在保存它的这个角度来看呢，对它的第一个第一重阳气，就是阳气的它的那个确定状态，阳气的它的状况啊，阳气的它的那个它作为一个被动的实体的一个自我持存，把它阳气掉了。

Edited: 它反而……that first sublation of it appears in this respect at the same time also in this way, namely that only some determinations are sublated in it and its identity in the effect with efficient cause occurs in it externally。就是说，对它的第一重扬弃，在保存它的这个角度、这一方面来看，对它的第一重扬弃扬弃的是它的确定状态、它的状况，扬弃的是它作为一个被动实体的自我持存，把它扬弃掉了。

## Paragraph 60: 2935505–2955985 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2935)

Segments: `t600:s451`, `t600:s452`, `t600:s453`, `t600:s454`, `t600:s455`

Original: 这个东西呢，它同时怎么样？Also in thisway，同时也以就以这种方式，namely啊，that only some determinations are sublated in it。就是说，你就会觉得就是说，你哪种方式啊？你就会以为就是说，它只是被阳气的一些规定，它本身还在啊。

Edited: 这个东西同时怎么样？Also in this way，同时也以这种方式，namely that only some determinations are sublated in it。就是说，你会觉得：它以哪种方式？你会以为它只是被扬弃了一些规定，它本身还在啊。

## Paragraph 61: 2956945–3036305 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=2956)

Segments: `t600:s456`, `t600:s457`, `t600:s458`, `t600:s459`, `t600:s460`, `t600:s461`, `t600:s462`, `t600:s463`, `t600:s464`, `t600:s465`, `t600:s466`

Original: 哦，我知道了，哦，我知道了，Iunderstand啊，直播我我明白了，我他妈明白了，and啊，我我我呕了，我只能说，and就是后面这个阳气相当于毁灭罪证啊，这个第二次的这个阳气可以看成是毁灭罪证，sublating its identity as itssublating啊呃，it sublates the thissubstance，它阳气的这个实体啊，阳气的这个作为脚手架这个实体，作为这个预先支撑的这个活动，或者说它遗忘了这个预先支撑的活动，它反而一次保存，就好像就是说这句话就在第一重阳气里面，就好像说这个实体它本就在那边了，我只是说把这个实体的被动性给它阳气掉了，我只把它一个规定给它阳气掉了，把它一个确定状态给它阳气掉了，namely that only some determinations are sublatedin，只有一些只有某些规定啊，其中的某些规定被阳气了，and its identity in theeffect，而它在那个效果当中的同一性with efficient cause occurs in itexternally啊，而这个实体它在效果当中啊，它依然会有一个同一性，依然会有同一性，依然会有identity，它会有新的identity。哦，它在哪个效果？什么效果？

Edited: “I understand。”我明白了，我他妈明白了。and……我只能说，我都要呕了。and 就是：后面这个扬弃相当于毁灭罪证；这个第二次扬弃可以看成毁灭罪证，sublating its identity as its sublating。呃，it sublates this substance——它扬弃了这个实体，扬弃了这个作为脚手架、作为预先支撑活动的实体，或者说它遗忘了这个预先支撑的活动。它反而被保存了；就好像这句话就在第一重扬弃里面，好像说这个实体本来就在那边了，我只是把这个实体的被动性扬弃掉了，只把它一个规定扬弃掉了，把它的一个确定状态扬弃掉了，namely that only some determinations are sublated in it。只有某些规定被扬弃了，and its identity in the effect with efficient cause occurs in it externally。而这个实体在效果当中依然会有一个同一性，依然会有 identity，它会有新的 identity。哦，它在哪个效果？什么效果？

## Paragraph 62: 3036305–3070883 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3036)

Segments: `t600:s467`, `t600:s468`, `t600:s469`, `t600:s470`, `t600:s471`

Original: 这个效果讲过了，这个效果的effect是很明确的啊，就是itseffect，就是说这个实体被我牵引着回转它的自身了，就是这么一个效果，这个实体被我教乖了，它不它不再迷失了，又回去了。那么就这个时候你就会觉得，哎，有个实体，有个实体，这个实体就会有一个同一性啊，有个同一性，哎，它就这个实体好乖哦，它不迷路的，它又回去了啊，with efficient cause occurs in itexternally，它在在这么一个结果当中的那个啊实体，它又获得统一性。

Edited: 这个效果讲过了，这个效果的 effect 是很明确的，就是 its effect：这个实体被我牵引着回转它的自身了，就是这么一个效果；这个实体被我教乖了，它不再迷失了，又回去了。这个时候你就会觉得，哎，有个实体，有个实体，这个实体就会有一个同一性；这个实体好乖哦，它不迷路的，它又回去了，with efficient cause occurs in it externally。它在这么一个结果当中的那个实体，又获得统一性。

## Paragraph 63: 3071363–3119043 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3071)

Segments: `t600:s472`, `t600:s473`, `t600:s474`, `t600:s475`, `t600:s476`, `t600:s477`, `t600:s478`

Original: 这个实体就是说，它的一些错误的规定被扬弃掉了。错误的规定就是说什么迷失在initself里面，迷失在那个passive里面，迷失在一个前面那个活的那个东西里面啊。然后with efficient cause occurs inexternally，它是这个效果，它是啊靠着那么一个起作用的原因，就是那个主动性的个力量，主动性的力量在它当中发生啊，在它当中发生，但是是外部的发生，好像就是说那个主动性的力量外部的，就是好像这个这个起作用的这个cause啊，efficientcause就是causality，这个时候cause就是说我他妈现在是causality，I am something efficient，I am efficient，I am the efficient side of the substance。

Edited: 这个实体就是说，它的一些错误的规定被扬弃掉了。错误的规定就是说什么迷失在 in itself 里面，迷失在那个 passive 里面，迷失在一个前面那个活的那个东西里面。然后 with efficient cause occurs in externally，它是这个效果，它是靠着那么一个起作用的原因，就是那个主动性的力量，主动性的力量在它当中发生，在它当中发生，但是是外部的发生，好像就是说那个主动性的力量是外部的，就是好像这个起作用的这个 cause，efficient cause 就是 causality。这个时候 cause 就是说我他妈现在是 causality，I am something efficient，I am efficient，I am the efficient side of the substance。

## Paragraph 64: 3119763–3197523 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3119)

Segments: `t600:s479`, `t600:s480`, `t600:s481`, `t600:s482`, `t600:s483`, `t600:s484`, `t600:s485`, `t600:s486`, `t600:s487`, `t600:s488`

Original: 哎，它好像是在这个原因就好像是我让你这个实体从passive让你一洗passive的规定把它洗掉了，扬弃掉。另外一方面就是说啊，它也同时也就忘掉了这个东西就是它自己设定的。然后另外一方面呢，他说我洗掉它就是洗掉它的这个它的这个忘掉它自己是它自己设定的这件事情，就俨然就好像这个实体有它有就就这个时候这个cause这个causality就外在的操作这个实体的，这个结构是很精妙的，这个结构非常精妙啊，它就是外在的好像我把这个一个僵死东西又转活了，外在的啊causality啊或者这一个efficientcause它外在的把这个substance从一个僵死东西转活了，怎么把它从僵死转活呢？就是说我让它知道，这个时候就变成其实始终是对一个僵死东西进行操作，其实它还是自忘的，因为这causality本身也是substance的一个力量啊，它还是自忘的嘛，懂吗？它还是自忘的，这过程中它一直是自我迷失的，但是它以为它克服了这自我迷失，它俨然以为自己克服了它的passivity，明白吗？

Edited: 哎，它好像是在这个原因，就好像是我让你这个实体从 passive，让你一洗 passive 的规定，把它洗掉了，扬弃掉。另外一方面就是说，它也同时也就忘掉了这个东西就是它自己设定的。然后另外一方面呢，他说我洗掉它就是洗掉它的这个、它的这个忘掉它自己是它自己设定的这件事情，就俨然就好像这个实体有、它有就——就这个时候这个 cause、这个 causality 就外在的操作这个实体。这个结构是很精妙的，这个结构非常精妙啊，它就是外在的，好像我把一个僵死东西又转活了；外在的 causality 或者这一个 efficient cause，它外在地把这个 substance 从一个僵死东西转活了。怎么把它从僵死转活呢？就是说我让它知道。这个时候就变成其实始终是对一个僵死东西进行操作，其实它还是自忘的，因为这 causality 本身也是 substance 的一个力量啊，它还是自忘的嘛，懂吗？它还是自忘的，这过程中它一直是自我迷失的，但是它以为它克服了这自我迷失，它俨然以为自己克服了它的 passivity，明白吗？

## Paragraph 65: 3198163–3243683 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3198)

Segments: `t600:s489`, `t600:s490`, `t600:s491`, `t600:s492`, `t600:s493`, `t600:s494`, `t600:s495`, `t600:s496`, `t600:s497`, `t600:s498`

Original: 所以它这个时候它只是occurs in itexternally是外在的在其中发生的occurs in itexternally，这么一个啊这个这个这个efficientcause所引发的这个effect它是occurs in itexternally，就好像因为这个时候这个efficientcause它还没有意识到这个passivesubstance是它自己，它没有意识到，它拒绝承认这一点，拒绝承认，所以这是扬弃了它的那个presupposing，扬弃了这个presupposing，它不承认这个presupposing，所以这叫扬弃了这个presupposing啊，它把这个扬弃掉了，就给提前支撑它自己把它忘掉了，它就觉得自己自己反而是激活这个的东西的大恩人。

Edited: 所以它这个时候它只是 occurs in it externally，是外在的在其中发生的，occurs in it externally，这么一个这个 efficient cause 所引发的这个 effect，它是 occurs in it externally。就好像因为这个时候这个 efficient cause 它还没有意识到这个 passive substance 是它自己，它没有意识到，它拒绝承认这一点，拒绝承认，所以这是扬弃了它的那个 presupposing，扬弃了这个 presupposing；它不承认这个 presupposing，所以这叫扬弃了这个 presupposing。它把这个扬弃掉了，就给提前支撑它自己把它忘掉了，它就觉得自己反而是激活这个东西的大恩人。

## Paragraph 66: 3244015–3276175 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3244)

Segments: `t600:s499`, `t600:s500`, `t600:s501`

Original: 那种感觉，我才是那个efficient substance。I am the efficient substance。I am the啊，I am the efficient cause，cause啊，cause as a substance。明白了吗？那么，那么to this accident it suffers violence。就在一这个意义上讲，它就承受暴力。Violence is appearance of power or power as external。那么，所谓的暴力就是啊，就是这个力的力量的表象，或者说它是外在的力量。

Edited: 那种感觉，我才是那个 efficient substance。I am the efficient substance。I am the，啊，I am the efficient cause，cause 啊，cause as a substance。明白了吗？那么，那么 to this accident it suffers violence。就在这个意义上讲，它就承受暴力。Violence is appearance of power or power as external。那么，所谓的暴力就是这个力的力量的表象，或者说它是外在的力量。

## Paragraph 67: 3277135–3309535 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3277)

Segments: `t600:s502`, `t600:s503`, `t600:s504`, `t600:s505`, `t600:s506`

Original: 他就以为他在他在操作一个他，他就以为他是个他自己对自己施加，他实际上是是自己对自己施加力量。他竟然以为他是外在的对把这个东西由由钝激活了，他没有意识到是这个东西自己在在，他没有意识到是他自己在，you understand？他他自己在，那么这么一个这么一个机制，他没有意识到是他自己在激活他自己，啊，激活他他自己。

Edited: 他就以为他在操作一个他，他就以为他是自己对自己施加，他实际上是是自己对自己施加力量。他竟然以为他是外在地把这个东西由钝激活了，他没有意识到是这个东西自己在、他没有意识到是他自己在，you understand？他自己在，那么这么一个机制，他没有意识到是他自己在激活他自己，啊，激活他自己。

## Paragraph 68: 3311535–3322335 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3311)

Segments: `t600:s507`, `t600:s508`, `t600:s509`, `t600:s510`

Original: 他就在这个意义上讲，实际上那个被动的实体实际上被是被保存了。就黑格尔在这非常了不起，非常完美。这个被动的实体是被保存了。他以为他扬起掉了，没有被扬起。

Edited: 他就在这个意义上讲，实际上那个被动的实体实际上是被保存了。黑格尔在这非常了不起，非常完美。这个被动的实体是被保存了。他以为他扬起掉了，没有被扬起。

- “扬起”疑为“扬弃”的听录，保留原词; 扬弃; t600:s510

## Paragraph 69: 3322975–3350735 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3322)

Segments: `t600:s511`, `t600:s512`, `t600:s513`, `t600:s514`, `t600:s515`, `t600:s516`, `t600:s517`, `t600:s518`

Original: 他就是说这个被动的东西被我变成一个积极的东西了。我操，那个积极东西那个积极性加载的那个玩意还不是个被动的东西，还是个被动的东西啊。你这个被动东西是被你保留下来的。你好像我把它由死转活了。我操，那这个那这个活的东西除去它的活性之外，它还不就是个死的东西？还不就是个被你操作的东西？还不是个外在于你的东西？你其实你和它是一体的，你就是它，你没有没有差别。

Edited: 他就是说这个被动的东西被我变成一个积极的东西了。我操，那个积极东西、那个积极性加载的那个玩意，还不是个被动的东西，还是个被动的东西啊。你这个被动东西是被你保留下来的。你好像我把它由死转活了。我操，那这个活的东西除去它的活性之外，它还不就是个死的东西？还不就是个被你操作的东西？还不是个外在于你的东西？你其实和它是一体的，你就是它，你没有差别。

## Paragraph 70: 3351215–3383295 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3351)

Segments: `t600:s519`, `t600:s520`, `t600:s521`, `t600:s522`, `t600:s523`, `t600:s524`

Original: 他还没有把握到这一点，所以在这个意义上，这个力量啊就是violence。这个时候这种力量就是一个力量的表象啊，就是violence。就是他自表面上看好像它是力量啊，他以为它是力量，他自以为这是力量。表面的他说力量的表象就是暴力，他以为在施加一个他从外而内的施加一个力，在在调教这个东西，实际上是他自己，实际上是他自己啊。Power as external啊，就很很有意思啊。

Edited: 他还没有把握到这一点，所以在这个意义上，这个力量就是 violence。这个时候这种力量就是一个力量的表象，就是 violence。就是他表面上看好像它是力量，他以为它是力量，他自以为这是力量。表面的，他说力量的表象就是暴力；他以为在施加一个他从外而内施加一个力，在调教这个东西，实际上是他自己，实际上是他自己啊。Power as external。啊，就很有意思啊。

## Paragraph 71: 3383295–3406495 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3383)

Segments: `t600:s525`, `t600:s526`, `t600:s527`, `t600:s528`

Original: 那么今天就讲到这边，这个预习课的话，这两段其实是啊它的蕴思是非常非常有有味道的啊，有味道的，就是那后面就希望你们自己去把握啊，自己去把握。这黑格尔在这里就是这个poweras，呃不不这个violence as external power。

Edited: 那么今天就讲到这边。这个预习课的话，这两段其实它的蕴思是非常非常有味道的，有味道的，就是——那后面就希望你们自己去把握，自己去把握。这黑格尔在这里就是这个 power as，呃不不，这个 violence as external power。

- “蕴思”疑为“运思”的听录，保留原词; 运思; t600:s525

## Paragraph 72: 3406655–3417935 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3406)

Segments: `t600:s529`, `t600:s530`, `t600:s531`, `t600:s532`

Original: 这个东西呢，齐泽克也没有做文章啊。其实齐泽克没有做文章。其实这这段我们就我觉得我们需要去做文章去把握它啊，需要去做文章去把握它。好，那就讲到这边啊，那就讲到这边。

Edited: 这个东西呢，齐泽克也没有做文章。其实齐泽克没有做文章。其实这段我们就我觉得我们需要去做文章去把握它，需要去做文章去把握它。好，那就讲到这边，那就讲到这边。

## Paragraph 73: 3419055–3447745 ms

[Watch](https://www.bilibili.com/video/BV1cq4y1t7TN/?p=1&t=3419)

Segments: `t600:s533`, `t600:s534`, `t600:s535`, `t600:s536`, `t600:s537`

Original: 这个预习课是挺痛苦的，但是实际上就是这也是他的文本了不起伟大的地方所在。他每一段这个东西都是非常有嚼头的，非常有嚼劲的啊，非常有嚼头，非常有嚼劲。然后就一般的，就是不是职业玩家的人读不懂，那也很正常啊，也非常正常。那也就是说，好，那就讲到这边啊，毕竟是几千年李治史的巅峰啊，讲这里啊。

Edited: 这个预习课是挺痛苦的，但是实际上这也是他的文本了不起、伟大的地方所在。他每一段这个东西都是非常有嚼头的，非常有嚼劲的，非常有嚼头，非常有嚼劲。然后就一般的，就是不是职业玩家的人读不懂，那也很正常，也非常正常。那也就是说，好，那就讲到这边，毕竟是几千年李治史的巅峰，讲这里啊。

- “李治史”疑为“逻辑史”的听录，保留原词; 逻辑史; t600:s537
