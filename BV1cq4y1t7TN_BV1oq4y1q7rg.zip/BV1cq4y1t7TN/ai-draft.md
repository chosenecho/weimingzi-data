我们今天讲主一主的预习课，这个预习课就是下面的二杠一杠四的预习课，我们需要先把文本、先把课文读一遍。就是行动啊、作用和反作用，action and reaction，或者行动和反行动，可以翻译成行动和反动了。

然后运行到这边呢，这个 cosolidity 已经暴露出来，它是一个预设性的、presupposing 预设者的活动性。它这种活动性属于这个主动性，这个主动性就是 principles、principle something、principle something that，就是把这个东西早就存在了；原因这个东西就是——前面讲过了——这个 cosolidity 就是它设了一个东西，并且把这个东西说成早就在这边了。

它这种活动性是一种……但这种活动性有好几个，这个 presupposing 的东西其实前面有好几个，不仅仅是 cosolidity。cosolidity 就是把 effect 设定下来，这个 effect 会说：哎，早就有这个 cause，让这个 effect 变成一个 effect 出来。

然后在这个情况下，这 cause is conditioned，这个原因啊，它就是有条件的，conditioned，it is negative reference to itself，它是一个否定性的指称、指向自己。它作为一个被预设的东西，就变成有条件的东西了；它否定性地指向自己。

通过什么指向自己？通过 effect，通过效果，它否定性地指向自己，说这个 cause 早就在那边了；effect 说早就有个 cause、有一个原因在那边了。这就叫做把自己设立成……就是指向自己、否定性地指向自己。然后我是 effect，我不是那个 cause，所以叫否定性地指向自身，把自己指向，而且是把自己变成一个本就在那边：我是 effect，我这个 effect 之前就有个 cause，我不是那个 cause。就是否定性地指向他自己，实际上就是他自己了。然后说那个 cause 早就在那边，也就是说把那个 cause 当成一个 presupposed、早就预设好的一个东西，否定性地指向了一个东西。

所以它是一个预设性的活动性，它把自己当成一个早就存在的东西，设定在自己后面或者自己前面，说“我早就在那边了”。然后它就是说，作为一个外在的一个他者，external other，外部的一个他者，which is in self，but only in itself is cosolidity itself。这个东西呢，它自在的，并且仅仅是自在；但是它仅仅是在……原因性本身才是 causality，起因性本身、causality 本身，就是背后那个 causality，背后那个 causality。就他把自己设立成是一个 external other。

他只有在他自身当中，就封闭地来看这个设定过程本身、封闭地来看这么一个活动过程本身，作为一个 external other。这个 external other 就是他只有在他自己当中封闭地看这么一个：就是我背后早就有个大哥，是 cause；或者说我背后早就有个大哥，这个东西甚至只有在他 in……这个背后就是 cause 了，背后是 cause。然后这个东西、这个 cause 是一个被 presupposed 的一个东西，是一个被 presupposed 的一个东西。

但是就其自己而言，孤立地就其内在而言，他自己看他自己，他会觉得他是 causality，他是 causality，施加在一个东西上面，施加在一个东西上面。就是 only in itself，它才是 causality。啊，但是我们很多庸常的人就以为那个 cause 就是 causality；不是，那个 cause 实际上是一个 presupposed、negative reference to itself，啊，to effect，the……

这个背后的那个 cause 是一个 presupposed，然后是一个 negative reference to effect，是 effect，是一个效果对于他自己的否定性指称。

然后这个东西就是仅在它自己看来，他好像是一个设定性的力量，很屌的一个力量，就是这个背后的那个 cause；仅在它 in itself 里面，作为一个外在东西，它仅在它 in itself 里面，它才是 causality itself，它才是个 causality。或者就这个理解，你就类似于说，举个例子，就比如说费希特的鲜艳自我、transcendental……

就是那个 ish，就是那个 ish 加引号的 ish，就是我自我，他自我学嘛、知识学，那个东西也是的：那个东西仅就它在它自身当中，它才是纯粹知识，它才是 pure knowledge。这里类似的理解就是说：这个 cause——我这个 effect 背后有个 cause——这个 cause 仅就他自己封闭地看他自己，封闭地、就他内在地，他就是自顾自的，他才是 causality。实际上他就是说，他以为他在对这个 effect 在施加什么力量。

this other is as we have seen the substantial identity，呃，into which formal causality passes over。那么这么一个他者，这个 external other 啊，就是说这个时候原因、因果性被固定到说 effect 背后有个 cause，就是之前上面一环有 cause，就 cause 会被看成是一个实体。这么一个外在他者，如我们所见，它会被看成是一个实体性的同一性；它是一种实体性同一性。形式的……形式的啊，这个因果性呢、形式的起因性呢，就是 pass over into it，转入了，对吧？过渡到了这种实体性的同一性当中，substantial identity，which……

这个时候就会，这个时候我们就会说 cause 它是一个实体，它是一个东西、一个原因；cause 就形式 causality 就 pass over into the substantial identity，实体性同一性里面去了。

进去了之后，我们就可以说有一个 cause，然后它导致了一个 effect、导致了一个效果，which now has determined itself as against this causality as its negative。那么现在呢，这个东西、这个他者、实存性的他者呢，它现在已经把自己规定成是和这个因果性、形式因果性对立的一个东西，作为它的否定项、作为它的 negative、作为它的否定侧和它对立起来。那么这个 cause 就好像是要从这个 cause 当中发起出一个 causality 出来，然后过渡到这个 effect 上面。那么这个形式因果性呢，它就是和这个 cause、substantial identity 这个 cause 对立起来，cause and causality 就对立起来了；它把自己对立起来了，or it is the same as the substance of the causal relation……

或者说它就是同样的，就是那个因果关系当中的那个实体，因果关系当中的实体，但是它是这样一个实体，but which is confronted by the power of accidentality as itself substantial activity。啊，它是这样一个实体，它是面对着这个偶性性的那个力量的；the power of accidentality，偶性性的力量本身才是真的力量，实体性的活动性，偶性性的力量本身才是力量，偶性性的 power of accidentality 其实就是 power of causality，偶性性的力量就是实体性的力量。

这就是实体的活动性，也就是因果性，即起因性的力量；causality 作为一种 power，属于 accidentality。因为 accidentality 引发这个效果，引发这个回指的效果，所以这个时候这个实体就和它对立起来了，和这个 power of accidentality 对立起来；而 accidentality 的力量本身则是这个实体的活动性。

所以这个时候，这个 cause 变成一个实体，这个实体只是纯粹地和这个起因性对立起来，和 causality 对立，和 accidentality 对立。为什么要和它对立？因为它要把自己预设下来：我早就在这边。所以它要和这个活的东西对立起来；这个活的东西会回来看穿这个轨迹，看穿它自己把自己设定下来、预设出来的这么一个轨迹，所以它要和这个轨迹对立起来。

这个 accidentality 和这个 causality 其实都是一种轨迹；或者说，形式因果性，formal 形式因果性，和这个 accidentality 其实是同一个东西，它们都是轨迹。这个轨迹就是在前面东西的轨迹：既然它可以回指一个背后的大哥，那凭什么这样？不能这样。就是我大哥本就在这边，大哥本就在这边，这个大哥本就在那边；这个“本就在”就是自我同一，实体性的自我同一就会和这个轨迹性的力量对立起来。

那么这个东西自己则是实体性的活动性；这个东西才是真正的实体性的活动性，是很厉害的。但是这个时候大哥变得僵硬了，大哥把自己伪装成 cause，把自己伪装成那个 causal relation 的实体；那么这个实体就是一个被动的实体，就是 passive substance，passive substance 就是被动的实体。

然后 passive is that which is immediate；它是被动的。什么是被动呢？就是那个直接的东西：that which is immediate，immediate is passive。它是直接的，or which exists in self but is not also for itself；它就是那个自在实存的、但又不是为它自己实存的东西。它自顾自地实存，像愣头青一样觉得自己是在决定一切、主宰一切，它是出来的，愣头青一样觉得自己是出来的。但是，but is not also for itself，它这个出来并没有任何目的，或者说没有任何意义，看不到它是在计划之中的，它没有任何计划性。for itself 呢，就是没有；它的自我确证是一个盲目的自我确证，是一个直接性、不加中介的自我确证，没有把自己展露出来，but not for itself，not for itself，just in itself，is not；这个就是被动，被动的一个东西。

这个时候，原因 cause 就会被看成是一个实体，或者说被看成因果关联、因果关系当中的实体，它的 substance。然后：Pure being or essence in just this determinateness of abstract self identity；它只是纯粹的存在或者纯粹的本质，在这种规定性当中——在哪种规定性、哪种确定状态、哪种明确状态呢？就是说抽象自身同一性。它只是一个抽离的自身同一、抽离的自我同一性的规定状态；它被什么东西规定？就是被一个抽离了的自我同一所规定。它只是 abstract self identity，所以它是 in itself；它是 exist，它是实存地出来的。所以这里 pure being 就是说，用了 all essence；它说这是 existence。existence 这个东西非常有意思，它是个实存，所以这里加个 all。为什么黑格尔在这里加个 all 啊？

其实挺值得玩味的：因为它是个 existence，但是它没有办法做到 for itself；这个 existence 没法返回它自己，它只是 in itself，not for itself，它无法返回它自己，所以它只是个孤零零的一个 being。

那另外一方面又可以说它是个 essence；这个 essence 实际上是有贬义的。它只是个 essence，它不是一个 concrete existence，所以它只是一个 in itself。蒙在里面的这个 essence 是一个相当于 being 的 essence，它不是 concrete existence。你不要说前面说它是 exist in itself，所以后面说它 essence 是在抬举它——不是的，没有抬举它。这里说它还是一个不明所以的、自顾自在那边的一个东西：我就是原因，我就是大哥，我就是大哥，就往那一站，因果网络全都要铺设在我身上，从我这里发出，我来吧；它就是个被动性 passivity，被动的一个东西。

面对这么一个被动的实体，和它相对立的是什么呢？是一个否定性的自我指涉的实体，the negatively self\-referent substance。有另外一个实体，就是活络的那个实体；它是面对这个东西的，活络这个实体是 the efficient substance，是那个起效用的实体、有效的实体、起效用的实体。it is caused in as much as in determinate causality it has restored itself out of the effect through the negation of itself；就是说，在明确的因果性当中——在 determinate，也就是规定的、我们可以翻译成确定的——在确定的因果性当中，只要是在确定的因果性当中是原因，它保存了它自身，从结果当中保存了它，是 restore itself out of the effect。

从这个效果、从它效果当中把自己保存下来，通过什么？through the negation of itself，通过自我否定。就是说，这个原因怎么把自己保存起来？我不是原因了，I am no longer cause，I am just something indifferent，I am the former cause of yourself；不是我，不是原因了。这个 cause 能把自己从这个效果当中保存下来的唯一方式，就是通过自我否定：I am no longer cause，I don't have causality。这个 cause 就变成一个被动的实体了，就变成一个被动的实体了。然后它是一个 reflected being，which in its otherness or as an immediate behaves essentially as a positing activity，and through its negation meditates itself。

这是被拉伸添上去的；Hegel's sentence does not otherwise pass，这是添的，这是拉伸添上去的。

which in its otherness：这么一个原因，这个原因（cause）就是一个实体，是一个东西，它是在那个因果关系当中的一个原因，不是原因性，不是 causality。它在它的他异性当中（otherness）——这个他异性也不就是前面的 external other——以它的他异性，或者说作为一个直接者，或者说不加中介的东西，作为一个 in itself 的蛇皮东西，behaves essentially as a positing activity。它本质性地一定会作为一个设定性的活动性、a positing activity 起作用，and through its negation mediates itself；然后通过它的否定来中介它自己，通过它的否认来中介它自己。因为它作为一个 otherness，它不可避免地一定会 essentially 按其本质作为 other 的东西，作为一个 reflected being——啊，这个是添下去的、添进去的：它就是告诉一个被反思的存在，肯定会按照这种方式来运动，a reflected being，it's a reflected being。

being 是一个被反思的存在，这个东西很膈应。你看，一个 being 只能是一个直接的 being，它竟然是个被反思的 being，reflected being——how could being be reflected？那么它一定会做后面的事情。一个 being，如果它被……因为这个 being 是什么？immediacy？直接性。但是他既然被反思了，就像这个时候这个原因也被反思了，reflected；或者说我们说它是一个被反思出来的一个 being。就这个 cause，这个时候这个 cause 把自己拯救出来了，把自己从这个炸生炸灭或不停献祭的因果网络里面拯救出来了——不是因果网络，他就是说把自己变成这个因果网络里面的一个被动的实体，好像 cosolidity 加载在这么一个 substance 上面，变成一个 cause，这个 cause 再传递到下面一个 effect 上面去；然后这个 effect 又变成一个……然后他自己又变成一个有着 cosolidity 的一个 substance，然后再搞到下面一个上面去，你懂吗？就这么个意思。所以在这种情况下，这个 cause，我们说它是一个 a reflected being，reflected being，是一个被反思、一个反思出来的、被反思了的一个存在。这个存在就是它被炮制出来的，它是被短路出来的一个自在。

一个封闭——这个封闭其实是被外面的东西给它包裹起来的；它不是一开始就没有内在，它是被绝对者封闭出来的，是被做出来的一个封闭性的东西。这是一个 reflected；其实 being 是个 in itself，或者它是一个 immediacy，不加中介、非中介性，但是它又是一个被 reflected、被炮制出来的东西。所以它加了一句：这个东西在它的 otherness 当中——或者说它的 otherness。什么叫它的 otherness？因为它是一个 being。它 being 是什么意思？就是它是个 otherness；对于 essence、对于理智而言，它是个 otherness，它是被我打包起来、封闭起来的东西。封闭之后里面是啥，我不知道了。就是这个 cause 好像是个密闭的东西了，所以它是个 otherness，我对这里面的东西不知了——故意不知道的，你知道吗？故意把它封闭起来了。他在他的这种他异性当中，或者说作为一个非中介者，or as immediate，不被中介的一个东西，它 behaves，它本质性地、essentially 就是因为它是个 reflected being；它是个 reflected being，它是一个高阶 existence，你知道吗？它是个高阶的、高阶的一个模组。就是自己把它——实际上它是敞开的呀，但是我把它封装起来，我说它是一个脱离的、封闭的，是一个意在的东西，我把它炮制成这么一个东西，就叫 cosolidity。它这个 cause 就是这么一种东西嘛，cause 就是这种东西。所以它本质性的——实际上它是一个本质论的装置，它是个本质论的装置；本质论里面才会有这种装置。或者其实实存论里面就会有这种，其实好多环节里面都会有这种装置：故意做一个东西，这个东西又说不是我做的，他自己就是他自己，就这么一种技巧。

那么这个东西，它本质性地必然会是一个 positioning activity，设定性的活动性，把它设定在那边——实际上是把它封冻在那边一个东西——然后通过它的否定中介他自己，and through its negation mediates itself。然后通过它的否定，实际上是中介它自身；实际上我们是理解了它，才理解了它、中介了它。我们通过它的否定中介了它；我不是直接中介它。我理解它，就是理解它的不可理解性，你懂吗？我中介它，就是中介它的不可中介性嘛，就叫 through its negation mediates itself。或者说，这个东西通过它的否定中介它自己；它中介了它自己。这个东西它的否定是什么？its negation 是什么？its negation 就是 its otherness to me，或者说 its negative as negative to the absolute，对于绝对者而言。你明白了吗？就好烦，是好烦，但是你熟悉这个思维方式就不烦了。Here therefore causality no longer has a substrate in which it inherits；在这里，因此，原因性或起因性再也不具有一个 substrate，no longer has a substrate in which it inherits。

它就不再具有一个机制，它是住在里面的了，它这个飘离的，懂吗？它是飘离的——in which it inherits；它就没有一个居住在其中、内附在其中的机制了。It is not a determination of form as against this identity, but is itself substance。Causality 这个东西呢，它就再也不是一个形式的规定，不再是一个形式规定，好像是对立于这么一种同一性，对立于 this identity，对立于同一性；同一性就是这个 substrate 和这个 causality 是一并一个的。它不再是一个形式规定性；它的对立——but is itself substance。它不是就是说……就在这里这个原因，因为它本来是个形式规定，然后对立于这个同一性：substrate 和这个 causality 的同一关系，它对立于此。如果是这样的话，我们就又回到前面去了。这里说这个状态、这个状况：it is not a determination of form as against this identity。这个状况指的并不是现状；这个状况就是说如果它是个 determination of form as against this identity。它只是说形式因果性和规定、确定因果性的一个对立，确定因果性（determinate）——它这一直贯穿的这种对立——but is itself substance；这个时候 causality 自己就变成 substance 了，is a passive substance which causality has presupposed for itself。然后这个……it is not determination for myself, but is itself caus—substance；这个时候 causality 本身就会被看成是实体。

或者换句话说，单单就靠这个 causality，单单靠起因性本身，它就是起源了，它就是源头，is at the origin。一开始就是纯的起因性、纯的 causality；一开始那个东西就不叫做实体了，我们也不把它叫做……就把它叫做 causality as a substance，就是 the first cause，the first cause。the substance、the substrate is a passive substance which causality has presupposed for itself。这个时候我们就可以说……

它有这个机制：causality 可以有 substrate。这个机制是一个被动的实体，而 causality 自己则是 efficient substance。Causality 自己说“我是一个 efficient substance”，而静态的 cause 是一个 passive substance。静态的 cause，或者说 causality 的载体——这个 substrate 可以翻译成“载体”，或者它的“机制”——载体就是 passive substance。因为前面我们讲的那个 cause，其实指的就是 substrate of the causality，它就是 passive substance。而 causality 本身则是一个活动性的实体，或者说 efficient substance。所以就有两种实体，实体分成两侧：一侧是 passive，一侧是 efficient；一侧代表 cause，一侧代表 causality；一侧代表 substrate，一侧代表 substance 本身，真正的那个 substance。This cause now acts：这么一个原因现在就会行动。结合到一块去，现在把它叫做一个 cause，它就会行动，for it is negative power over itself——因为它是对于自身的一个否定性的力量，它是对自身的否定性的力量。它说：I am not passive，I am not passive，所以它可以 act。At the same time，同时它 it is its own presupposition：它同时又是它自己的一个预设，它自己又是它自己的一个预设，它是它自己的前提。

它是它自己的前提，它必须存在为它自己的前提。它在前面是一个自己设定性的活动性，所以这个时候它把自己设定出来了，把自己设定出来了，好吧？原因性是一种这种活动性。那么 cause 由于它其实就是这个 causality 设置出来的一个 substrate，或者说一个 passive substance，然后变成这个 cause；这个 cause 上面，它那个否定性的力量指向它自己。其实通通都是它自己玩的。At the same time，同时它就是它自己的一个前提，它自己把自己作为前提设立出来。

因为你要说有一个 efficient power，或者 efficient activity，或者 substance，你得先有一个它施加在什么上面的东西，对吧？它施加在什么上面？它施加在什么上面？就好像这么一个惰性的东西开始行动了，就是这么个意思：这个时候原因就会把自己变成由静到动的一个过程。它本来是个惰性东西、passive 的东西，上面有一个活跃的力量行动起来了。

那么这一整个整体是它自己的前提，或者说那个僵死的、被动的那些部分就是它的前提。它先得有僵死的这部分、passive 那一部分，然后再开始动起来，它就把 passive 这部分设定成它的前提。因此，it acts upon as upon another，所以它 acts upon itself：它是对于自己起作用，就好像对于另一个它起作用一样。这个叫自因性，这就是你理解什么叫自因性了。一个因就有自因性：自己对自己，自己把自己驱动起来，就像头拽着自己头发把自己拽出沼泽。它就好像把这个行动施加在自己身上，就好像行动在一个“它”的身上；这个“它”就是就其 passive 而言，upon the passive substance，就是施加在那个被动性的实体上面。

因此，at first supplants otherness of this substance and returns it back to itself。它起先扬弃了这种实体的差异性，好像初步扬弃了。这个“first”就可以看出来了：它初步扬弃了它的这一种实体，这种被动的 passive substance。这个 passive substance 还记得前面是什么吗？是一个 reflective being。

这个东西是个很矬的装置，对不对？你们本质论没有学过，我直接给你讲这个——这其实还是本质论，所以你理解这个东西不太好理解。他妈的，本质论看多了，你知道这个屌东西到处都是：reflective being 到处都是，特别是你从 actuality 开始，全是你妈 reflective being；possibility 也都是 reflective being。很垃圾的玩意，它就是一个脚迹，你知道吗？就是 reflecting。就是说，其实我都懂，但是我故意装了不懂。这个东西是我故意装了不懂的一个我不懂的东西，就是这么个屌东西；它就好像是一个存在，它不是本质，不是一种反思，不是一种思维，它好像是个存在。

但是它实际上是已经被我反思过的；在谋篇布局当中，我故意搞出这么个假的、偏偏是我自己的一个小小东西。为什么要骗自己？因为要用一个谎言来解决之前那个谎言，为前面的谎言圆谎。前面的谎言就是“我是大哥，你前面的这些偶性全是小弟，你偶性指向的是我大哥”，但实际上是个谎言，那就只有他妈的前台的偶性，懂吗？他要为前面这个谎言圆谎，说这之间有个形式因果性，然后再搞出个确定的因果性，然后一步一步不停地圆谎，对吧？黑格尔的逻辑学就是这么一个过程，很挫的，实事求是的讲。哎，我们讲到哪里了？

然后就说，他起先好像扬弃了实体的那种他异性，然后 returns it back to itself；然后把这个东西 returns it back to itself，然后它在这个实体当中好像回到了它自身——这个活动性或者原因好像回到它自己，好像回家了一样。就是 cause 在它的这个 passive substance 里面，好像又重新重振雄风了。I am again causality：我又变成 causality 了。看上去，第一步起初看上去它好像又回到它自己；我这个 cause 又是一个活生生的东西了，又是一个牵引的力量，那种 originating 的力量了。然后第二步呢，it determines this same substance possesses sublation of its otherness or the substance turning back into itself as determinateness。

但是第二步呢，第二步它又规定了这同一个实体，它要把这同一个实体加以规定，把它明确化。这个 substance 怎么规定它呢？就是说，它把对于这个东西的他异性的扬弃设定出来；或者说，它就设定出这个实体本身是 the substance turning back into itself as determinateness。这个 passive substance 转回它自己，是它的一个 determinateness，是它的一个确定状态、明确的状态。posits or the sublation，它又把这个东西设定下来。

那么接下来看，这种被设定性，或者说这种被设定状态，because it is at seven times substance turning back into itself is at first its effect，就是它的效果，起先就是它的效果。这里怎么理解呢？就是说，第二步它规定了是同一个实体，它又规定这同一个实体，把它变成一种规定状态、一种明确状态。这个东西，你看到的是前面一步：它好像这 cause 在这里面，我把它牵引起来了——我操，我这个活跃的那部分，把被动那一部分给它牵引起来了。

那么第二步，立刻就要把这个——对于它的这个阳气——给它设定下来。也就是说，虽然我在第一步好像重新成为我自己的，但第二步就是说：你被我打败了，听懂这个意思吗？第一步起先他好像回到他自身，但第二步他立刻就不甘于仅仅回到他自身了，他又立刻跑出来说：你这个东西被我打败了；我是通过打败你才回到我自身的，我是通过激活你才回到我自身的。啊，他要把这么一个对于这个东西的、这么一个被动的实体的他异性的阳气，给它设定出来，给它设定出来。其实他回不回自身并不重要，回不回他自身并不是他的主要目的；他主要的目的是说：我是通过干掉你才回到我自身的，我是通过干掉你才从一个 cause 重新变成 causality，我是通过克服了我的惰性——其实是克服了他自己的惰性，或者克服了这么一个被动的实体——我才活跃起来的。

其实他不是为了活跃起来，他的目的是为了表明那个惰性被他克服，或者表明——他要把 substance、把这个实体本身的转回到它自身，把实体本身的回转回自身看成是一个明确状态，他要把这个东西规定下来。这里发生了一件什么事儿？什么东西是很明确的一个东西？一个一个状况在这里发生的是啥？是这个被动的实体它转回它自己了——turning back into itself，转回它自己了。我把它阳气掉了，我把它阳气掉了，这个玩意儿也消失了；这个东西是个被动东西，我把对于它的这种被动性、惰性这种他异性给阳气掉了。也就是说，要响亮地把对他的阳气给他说出来：你就是说，也这你看见吧？This——所以这种被设定状态，这种 positiveness，because it is at the same time the substance turn back into itself，由于它同时是这个实体的转回到它自身，实体回转它的自身，is at first its effect。

所以看上去是它的效果，好像看上去是它的效果。啊，看上去就是说：哎，好像就是我这个 cause 在成为 causality 的过程当中起到一个效果，就是让这个 passive substance 被我阳气掉了；啊，passive substance 被我阳气掉了，或者说我让这个 substance 回转回自身——让这个实体回转到它自身，实体又动起来了，实体返回到它自己了，我让这个实体又运动起来了。我让这个实体的谋篇布局又开始动起来了，它不再是一个 passive substance 了，听懂了吧？我让这个实体又开始按照它的那个谋篇布局又开始运动起来了，又转回到自身去了，不让这个实体摆脱了它在那个 reflected being 当中茫然自失的那种迷惑状态，或者那种自我遗忘的状态——就是卡在那边；我不让它卡住了，继续跑起来了，然后回到它自身了。所以它就是它的效果；它的效果就是说，这个时候这个 cause 就克服这个 passive substance，变成 causality；好像是它回到自身，但其实不是它回到自身，他说我又让实体又回到它自己了，又让实体又转起来、又动起来。我的效果就是这个。但是反过来说呢，but conversely, conversely, because as presupposing it determines itself as its other, it then produces effect in this other, in the passive substance。

但是由于，作为——或者说由于原因，或者说由于这个因果性，就是成为原因的这种蛇皮因果性——这个他妈的是一个很狡猾的戏的一个家伙。这个蛇皮因果性它作为一个预设活动，它怎么样？它规定它自己作为它的他者，determines itself as its other；它规定它自身作为它的他者，规定成什么了？determines itself 规定什么？规定成 cause 嘛？规定成 passive substance？加载在一个 passive substance，以 passive substance 作为 substrate 的一个 cause 嘛？啊，所以呢，它又把这个效果 in this other 又把这个效果设定下来，设定在这么一个他者当中，设定在这个他者——就是设定在 cause 里面，又把 effect、效果设定在 cause 里面。你看，这只有在这个 cause 里面，作为这个 cause act，这个 cause 本身就是一个被动和主动的结合体、结合嵌合体，我觉得是 passive substance 和这个 efficient substance 两个结合到一起去的一个东西。

所以它这个时候这个效果，这种效果它是要夹杂的：它 posit the effect。这个 the effect 就指前面那个 effect，前面那个 effect，它的 effect；它又把这个效果——这个效果就是那个结果，就是那个实体又回到它自己了——好了不起，嗯，应该是我克服了他的惰性；我作为一个原因，我帮他克服了他的惰性；我作为 causality，我帮他克服了他的惰性，他又回到他自己。但是他只能把这个效果设定在他的他者当中，只能把它设定在 cause 里面；这个 cause 只能，或者说只能把它设定在 this other 里面。这个 causality 只能把这个 effect——the effect of what? of that the substance is turning back to itself——把这个 effect posits in 哪里啊？in this other。other 是什么？other 就是 cause；那么这个 cause 是什么？cause 就是 the passive substance。啊，passive substance must be acted upon，by by 什么？efficient substance，这个东西。啊，你必须还是能把这个效果设定在一个被动的实体当中。或者 or again because the passive substance is itself this double。

或者说啊，反过来说呢，或者说换一种方式说：就是由于这么一个被动的实体，它本身就是这个加倍——什么的加倍呢？namely a self\-subsistent other and at the same time something presupposed and already implicitly identical with the efficient cause。由于这个被动的实体呢，本身就是一个自我持——一方面它是个自我持存的一个他者，自身持存，它自己就是持存的一个他者，是个比影；另外一方面呢，它同时 at the same time 就是某个被预设的东西。这个被预设的东西，它同时又是其实又是 causality 预设的玩意了，就是诡计——他妈的，其实就是我自己偷偷预设的，就这么意思。它又是某个被预设的东西，所以它早就已经是隐秘地等同于那个起作用的原因了，the efficient cause，或者说 the efficient substance。啊，由于这个东西呢，the——这个 action of the passive substance is therefore itself double。所以呢，那么这个被动的实体的它的行动，因此它就是加倍的，它就是加倍的，它就是加倍的，它本身就是加倍的。换句话说，就是你可以理解成这个被动实体，它的行动就加倍了，它的行动加倍。一方面——它加倍在哪里啊？It is at once both sublation of its determinations——它同时啊，既是对于它的那种规定状态或者明确状态，它的那个这种 determinations 的一个阳气，namely of its condition or the sublation of the self\-subsistence of the passive substance。也就是说，对于它的条件的一个阳气，或者说对于那个这种被动的实体的自身实存的一个阳气；它一方面是对于这个东西的阳气，就是把它驱动起来，把它驱动起来。

要让它动起来，不要让它陷在那种 determinators 里面；或者，不要把 condition 翻译成“条件的状况”。就它的状况而言，所谓“扬弃”是要扬弃什么？它是个 passive 的东西，是个 self\-subsistence 的东西，是一个 reflected being，是一个僵死的东西。一方面，你把它操纵起来、把它动起来，这个 cause 把它动起来；其实它本来就是动的力量。它的不动也是由它的动所设立出来的假的不动。所以，它同时一方面扬弃了这么一个假的不动——假装不再动的这么一个东西——这就是它的状态；把它扬弃了，把这个被动实存的自我实存状况扬弃掉。

另一方面，同时，and also in sublating its identity as it sublates this substance, the presupposing of itself—that is, the positing or supposing of itself as other。它同时——it is both and also——在扬弃它的同一性的时候，在 sublating its identity 的时候，它又扬弃了什么？它又扬弃了这个实体，扬弃了这个实体本身，扬弃了被动实体本身，又扬弃了它自身之前的一个假设，the presupposing of itself，这个前面支撑的 presupposing。

Hegel 在这里做文字游戏。你要理解这个 substance，这个 passive substance 实际上就是因果性自己给自己设定出来的、在前面做支撑物的东西。作为支撑物，相当于你要把自己拽起来，总得有个东西可以踩；要跳，也要踩着东西，而那个踩着的东西是你预设出来的，所以它用“之前支撑”这个说法。它要把这个之前支撑的脚手架之类的东西扬弃掉，把这个实体、被动实体给它扬弃掉。

在这个过程中，在它动的过程中，在 cause 的内在……在原因、起因，在 causality 把自己变成一个 cause，把自己变成 cause，就要把自己变成一个 passive substance，同时是一个 efficient substance 的这么一个玩意儿。这个玩意儿打包起来就是一个 cause。

那么，这个东西就其是个 passive substance 而言，它是个 in itself，它是个 being。前面都讲过了，我不想重复。

那么，一方面你把那个东西的僵死性扬弃掉了；另外一方面也把需要架设一个脚手架本身扬弃掉了，把这个东西本身扬弃掉了，也就是不认为它存在了。不仅仅是把它的被动实体的自我持存扬弃掉，把它的状况、它的确定状态，或者说把它的那种状态扬弃掉。

它也把这么一个东西扬弃掉了：它本身要预先支撑自己、提前支撑自己，搞一个东西说“那个东西之前支撑着我”，其实是骗人的，通通都是骗人的。辩证法通通都是骗人。但是 Hegel 会告诉你，这些骗人在本体论上是必要的；没有这个东西，根本不会有这些环节。That is the positin——就是本体论的机制，可以反常识；小朋友不能理解，别烦了。That is the positin or supposing，也就是说……

也就是说，它把这么一个实体本身扬弃掉了，把它自身之前的一个支撑、主动支撑的这么一个行动取消掉了。也就是说，把它自己作为一个他者来设定、或者支撑自己的这个主动过程——做一个他者来设定自己、做一个他者来支撑自己——这两件事情扬弃掉了。必须要做的已经动起来了，不需要这两个东西了。

那么，通过这最后一个环节，through this last moment, the passive substance is preserved。那个被动的实体反而被保存了。Hegel 这里很有意思：通过最后这个环节，被动的实体反而被保存了，preserved is preserved。这个词其实很有意思：反而被保存了，防腐保存起来，但是它就死了、僵死了、死掉了。

之前它是一个活的东西嘛？之前实际上是一个活的东西，是个 presupposing；之前它是个 presupposing，presupposing 闭合了，变成一个 in itself。然后说它是个 passive 的玩意儿，它只是一个 in itself；不，他就否定地说：我不是一个 for itself。“你不准回看，不准回看，看穿我的把戏，不准看啊。”然后这个东西就是一个有待被看的，是有待被看的。你不让我看，我就用另外一个东西来把你看，就是把它设定为一个他者，把它牵引起来，把它动起来了。它就是 a self\-subsistent other，就是动起来了。它是不准看、不准你去窥视它的；它只能自己在它自己那里，好好的那个样子。

它反而……that first sublation of it appears in this respect at the same time also in this way, namely that only some determinations are sublated in it and its identity in the effect with efficient cause occurs in it externally。就是说，对它的第一重扬弃，在保存它的这个角度、这一方面来看，对它的第一重扬弃扬弃的是它的确定状态、它的状况，扬弃的是它作为一个被动实体的自我持存，把它扬弃掉了。

这个东西同时怎么样？Also in this way，同时也以这种方式，namely that only some determinations are sublated in it。就是说，你会觉得：它以哪种方式？你会以为它只是被扬弃了一些规定，它本身还在啊。

“I understand。”我明白了，我他妈明白了。and……我只能说，我都要呕了。and 就是：后面这个扬弃相当于毁灭罪证；这个第二次扬弃可以看成毁灭罪证，sublating its identity as its sublating。呃，it sublates this substance——它扬弃了这个实体，扬弃了这个作为脚手架、作为预先支撑活动的实体，或者说它遗忘了这个预先支撑的活动。它反而被保存了；就好像这句话就在第一重扬弃里面，好像说这个实体本来就在那边了，我只是把这个实体的被动性扬弃掉了，只把它一个规定扬弃掉了，把它的一个确定状态扬弃掉了，namely that only some determinations are sublated in it。只有某些规定被扬弃了，and its identity in the effect with efficient cause occurs in it externally。而这个实体在效果当中依然会有一个同一性，依然会有 identity，它会有新的 identity。哦，它在哪个效果？什么效果？

这个效果讲过了，这个效果的 effect 是很明确的，就是 its effect：这个实体被我牵引着回转它的自身了，就是这么一个效果；这个实体被我教乖了，它不再迷失了，又回去了。这个时候你就会觉得，哎，有个实体，有个实体，这个实体就会有一个同一性；这个实体好乖哦，它不迷路的，它又回去了，with efficient cause occurs in it externally。它在这么一个结果当中的那个实体，又获得统一性。

这个实体就是说，它的一些错误的规定被扬弃掉了。错误的规定就是说什么迷失在 in itself 里面，迷失在那个 passive 里面，迷失在一个前面那个活的那个东西里面。然后 with efficient cause occurs in externally，它是这个效果，它是靠着那么一个起作用的原因，就是那个主动性的力量，主动性的力量在它当中发生，在它当中发生，但是是外部的发生，好像就是说那个主动性的力量是外部的，就是好像这个起作用的这个 cause，efficient cause 就是 causality。这个时候 cause 就是说我他妈现在是 causality，I am something efficient，I am efficient，I am the efficient side of the substance。

哎，它好像是在这个原因，就好像是我让你这个实体从 passive，让你一洗 passive 的规定，把它洗掉了，扬弃掉。另外一方面就是说，它也同时也就忘掉了这个东西就是它自己设定的。然后另外一方面呢，他说我洗掉它就是洗掉它的这个、它的这个忘掉它自己是它自己设定的这件事情，就俨然就好像这个实体有、它有就——就这个时候这个 cause、这个 causality 就外在的操作这个实体。这个结构是很精妙的，这个结构非常精妙啊，它就是外在的，好像我把一个僵死东西又转活了；外在的 causality 或者这一个 efficient cause，它外在地把这个 substance 从一个僵死东西转活了。怎么把它从僵死转活呢？就是说我让它知道。这个时候就变成其实始终是对一个僵死东西进行操作，其实它还是自忘的，因为这 causality 本身也是 substance 的一个力量啊，它还是自忘的嘛，懂吗？它还是自忘的，这过程中它一直是自我迷失的，但是它以为它克服了这自我迷失，它俨然以为自己克服了它的 passivity，明白吗？

所以它这个时候它只是 occurs in it externally，是外在的在其中发生的，occurs in it externally，这么一个这个 efficient cause 所引发的这个 effect，它是 occurs in it externally。就好像因为这个时候这个 efficient cause 它还没有意识到这个 passive substance 是它自己，它没有意识到，它拒绝承认这一点，拒绝承认，所以这是扬弃了它的那个 presupposing，扬弃了这个 presupposing；它不承认这个 presupposing，所以这叫扬弃了这个 presupposing。它把这个扬弃掉了，就给提前支撑它自己把它忘掉了，它就觉得自己反而是激活这个东西的大恩人。

那种感觉，我才是那个 efficient substance。I am the efficient substance。I am the，啊，I am the efficient cause，cause 啊，cause as a substance。明白了吗？那么，那么 to this accident it suffers violence。就在这个意义上讲，它就承受暴力。Violence is appearance of power or power as external。那么，所谓的暴力就是这个力的力量的表象，或者说它是外在的力量。

他就以为他在操作一个他，他就以为他是自己对自己施加，他实际上是是自己对自己施加力量。他竟然以为他是外在地把这个东西由钝激活了，他没有意识到是这个东西自己在、他没有意识到是他自己在，you understand？他自己在，那么这么一个机制，他没有意识到是他自己在激活他自己，啊，激活他自己。

他就在这个意义上讲，实际上那个被动的实体实际上是被保存了。黑格尔在这非常了不起，非常完美。这个被动的实体是被保存了。他以为他扬起掉了，没有被扬起。

他就是说这个被动的东西被我变成一个积极的东西了。我操，那个积极东西、那个积极性加载的那个玩意，还不是个被动的东西，还是个被动的东西啊。你这个被动东西是被你保留下来的。你好像我把它由死转活了。我操，那这个活的东西除去它的活性之外，它还不就是个死的东西？还不就是个被你操作的东西？还不是个外在于你的东西？你其实和它是一体的，你就是它，你没有差别。

他还没有把握到这一点，所以在这个意义上，这个力量就是 violence。这个时候这种力量就是一个力量的表象，就是 violence。就是他表面上看好像它是力量，他以为它是力量，他自以为这是力量。表面的，他说力量的表象就是暴力；他以为在施加一个他从外而内施加一个力，在调教这个东西，实际上是他自己，实际上是他自己啊。Power as external。啊，就很有意思啊。

那么今天就讲到这边。这个预习课的话，这两段其实它的蕴思是非常非常有味道的，有味道的，就是——那后面就希望你们自己去把握，自己去把握。这黑格尔在这里就是这个 power as，呃不不，这个 violence as external power。

这个东西呢，齐泽克也没有做文章。其实齐泽克没有做文章。其实这段我们就我觉得我们需要去做文章去把握它，需要去做文章去把握它。好，那就讲到这边，那就讲到这边。

这个预习课是挺痛苦的，但是实际上这也是他的文本了不起、伟大的地方所在。他每一段这个东西都是非常有嚼头的，非常有嚼劲的，非常有嚼头，非常有嚼劲。然后就一般的，就是不是职业玩家的人读不懂，那也很正常，也非常正常。那也就是说，好，那就讲到这边，毕竟是几千年李治史的巅峰，讲这里啊。
